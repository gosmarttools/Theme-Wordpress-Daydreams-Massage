import React, { useState, useEffect, useRef } from 'react';
import {
  Phone,
  Clock,
  MapPin,
  Star,
  ShieldCheck,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Menu,
  X,
  Check,
  Copy,
  ChevronLeft,
  ChevronRight,
  Calendar,
  UserCheck,
  MessageCircle,
  CheckCircle2,
  Award,
  HeartHandshake,
  ArrowRight,
} from 'lucide-react';

interface AdminInfo {
  id: string;
  name: string;
  label: string;
  phone: string;
  phoneDisplay: string;
  status: string;
  avatarBg: string;
}

const ADMIN_LIST: AdminInfo[] = [
  {
    id: 'siska',
    name: 'SISKA',
    label: 'Admin 1 (SISKA)',
    phone: '62895629139936',
    phoneDisplay: '+62 895-6291-39936',
    status: 'Online 24 Jam • Fast Response',
    avatarBg: 'from-pink-500 to-rose-600',
  },
  {
    id: 'erik',
    name: 'Mr.Erik',
    label: 'Admin 2 (Mr.Erik)',
    phone: '6285217344735',
    phoneDisplay: '+62 852-1734-4735',
    status: 'Online 24 Jam • Standby Dispatch',
    avatarBg: 'from-amber-500 to-amber-700',
  },
];

const HERO_SLIDES = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=1600&auto=format&fit=crop',
    tag: 'LAYANAN PIJAT PANGGILAN JAKARTA 24 JAM',
    title: 'Relaksasi Mewah & Privat di Kamar Hotel Anda',
    subtitle: 'Terapis profesional bersertifikat tiba dalam 30–45 menit di hotel berbintang, apartemen mewah, dan hunian Anda di seluruh DKI Jakarta.',
    highlight: 'Kenyamanan & Privasi Terjaga 100%',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1600334129128-685c5582fd35?q=80&w=1600&auto=format&fit=crop',
    tag: 'TRADITIONAL INDONESIAN MASSAGE',
    title: 'Kembalikan Stamina & Redakan Otot Lelah',
    subtitle: 'Kombinasi pijat urut tradisional khas nusantara dengan minyak aromaterapi esensial hangat untuk melancarkan sirkulasi darah dan tidur nyenyak.',
    highlight: 'Pilihan Terapis Pria & Wanita Berpengalaman',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?q=80&w=1600&auto=format&fit=crop',
    tag: 'REFLEXOLOGY & TOTAL WELLNESS',
    title: 'Totok Wajah, Refleksi, & Pijat Masuk Angin',
    subtitle: 'Solusi cepat tubuh pegal, masuk angin, dan stres setelah perjalanan bisnis atau aktivitas padat di ibukota Jakarta.',
    highlight: 'Respon Cepat Tengah Malam & Dini Hari',
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=1600&auto=format&fit=crop',
    tag: 'COUPLE MASSAGE & LULUR SCRUB',
    title: 'Paket Berdua & Perawatan Kulit Segar',
    subtitle: 'Dua orang terapis hadir bersamaan untuk Anda dan pasangan. Dilengkapi scrub herbal alami agar kulit bersih, halus, dan harum.',
    highlight: 'Minyak Aromaterapi & Perlengkapan Higienis',
  },
];

export interface MassageServiceItem {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  image: string;
  description: string;
  duration: string;
  focusArea: string;
  price: string;
  benefits: string[];
}

export const MASSAGE_SERVICES: MassageServiceItem[] = [
  {
    id: 'traditional-massage',
    title: 'Traditional Body Massage',
    badge: 'Paling Favorit',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=800&auto=format&fit=crop',
    description: 'Pijat urut tradisional seluruh tubuh meredakan rasa capek, melancarkan aliran darah, dan memberikan sensasi relaksasi mendalam.',
    duration: '90 / 120 Menit',
    focusArea: 'Kaki, Punggung, Bahu, Leher & Kepala',
    price: 'Rp 200.000',
    benefits: [
      'Relaksasi otot kaku & tegang',
      'Melancarkan sirkulasi peredaran darah',
      'Minyak esensial aromaterapi alami',
      'Bebas pilih terapis pria / wanita',
    ],
  },
  {
    id: 'reflexology-totok',
    title: 'Reflexology & Totok Wajah',
    badge: 'Segarkan Pikiran',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-300',
    image: 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?q=80&w=800&auto=format&fit=crop',
    description: 'Tekanan akurat pada titik refleksi telapak kaki untuk organ tubuh, dipadukan totok wajah segar bebas penat dan pusing.',
    duration: '60 / 90 Menit',
    focusArea: 'Telapak Kaki, Betis, Wajah & Titik Syaraf Kepala',
    price: 'Rp 175.000',
    benefits: [
      'Stimulasi zona titik syaraf kaki',
      'Totok wajah glowing & fresh',
      'Meredakan migrain & sakit kepala',
      'Tidur lebih lelap dan berkualitas',
    ],
  },
  {
    id: 'pijat-kerokan',
    title: 'Pijat + Kerokan Masuk Angin',
    badge: 'Khusus Masuk Angin',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    image: 'https://images.unsplash.com/photo-1600334129128-685c5582fd35?q=80&w=800&auto=format&fit=crop',
    description: 'Kombinasi pijat relaksasi tubuh dan teknik kerokan dengan minyak kayu putih / jahe hangat berkhasiat untuk mengusir rasa begah & dingin.',
    duration: '90 / 120 Menit',
    focusArea: 'Full Body + Kerokan Punggung & Leher',
    price: 'Rp 225.000',
    benefits: [
      'Mengeluarkan angin & rasa begah',
      'Meredakan meriang dan linu tubuh',
      'Kerokan higienis steril koin/tanduk',
      'Badan langsung enteng & hangat',
    ],
  },
  {
    id: 'lulur-scrub',
    title: 'Lulur Tradisional & Body Scrub',
    badge: 'Perawatan Kulit',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-300',
    image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?q=80&w=800&auto=format&fit=crop',
    description: 'Pijat relaksasi disertai eksfoliasi scrub rempah alami untuk mengangkat kotoran, daki, serta meregenerasi kulit agar lembut berkilau.',
    duration: '120 Menit',
    focusArea: 'Seluruh Tubuh + Scrub Herbal (Zaitun / Bengkoang)',
    price: 'Rp 275.000',
    benefits: [
      'Mengangkat sel kulit mati & daki',
      'Kulit bersih, cerah & wangi herbal',
      'Scrub zaitun / bengkoang premium',
      'Relaksasi tubuh total menyeluruh',
    ],
  },
  {
    id: 'deep-tissue',
    title: 'Deep Tissue / Pijat Otot Kaku',
    badge: 'Tekanan Kuat',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    image: 'https://images.unsplash.com/photo-1519824145371-296894a0daa9?q=80&w=800&auto=format&fit=crop',
    description: 'Tekanan bertenaga untuk mengurai simpul otot kaku bagi yang hobi berolahraga, fitness, atau lelah beraktivitas seharian.',
    duration: '90 / 120 Menit',
    focusArea: 'Otot Bahu, Pinggang, Punggung, & Betis Kaku',
    price: 'Rp 250.000',
    benefits: [
      'Tekanan kuat terfokus (firm pressure)',
      'Meredakan simpul otot leher & pinggang',
      'Sangat cocok setelah gym / golf / macet',
      'Terapis terlatih anatomi otot',
    ],
  },
  {
    id: 'couple-massage',
    title: 'Couple Massage Package',
    badge: 'Paket 2 Orang',
    badgeColor: 'bg-pink-100 text-pink-800 border-pink-300',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=800&auto=format&fit=crop',
    description: 'Layanan pijat berdua bersama pasangan. Hadir 2 orang terapis profesional secara bersamaan ke kamar hotel atau apartemen Anda.',
    duration: '120 Menit',
    focusArea: 'Full Body Massage 2 Orang Serentak',
    price: 'Rp 450.000 (2 Orang)',
    benefits: [
      '2 Terapis tiba bersamaan tepat waktu',
      'Privasi romantis di kamar hotel/rumah',
      'Minyak aromaterapi dobel varian',
      'Hemat & praktis tanpa perlu keluar',
    ],
  },
];

export interface TherapistItem {
  id: string;
  name: string;
  gender: 'wanita' | 'pria';
  age: number;
  experience: string;
  image: string;
  rating: number;
  reviews: number;
  specialties: string[];
  certification: string;
  standbyArea: string;
  badge: string;
  badgeColor: string;
  bio: string;
  available: boolean;
}

export const THERAPISTS_LIST: TherapistItem[] = [
  {
    id: 't-maya',
    name: 'Terapis Maya Putri',
    gender: 'wanita',
    age: 27,
    experience: '6 Tahun',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop',
    rating: 5.0,
    reviews: 312,
    specialties: ['Traditional Massage', 'Totok Wajah', 'Aromaterapi'],
    certification: 'Sertifikat BNSP Spa Therapist',
    standbyArea: 'Jakarta Selatan & Jakpus',
    badge: '⭐ Top Favorite',
    badgeColor: 'bg-pink-100 text-pink-800 border-pink-200',
    bio: 'Ramah, telaten, dan menguasai teknik urut relaksasi otot serta totok wajah penenang pikiran.',
    available: true,
  },
  {
    id: 't-rian',
    name: 'Terapis Rian Pratama',
    gender: 'pria',
    age: 29,
    experience: '7 Tahun',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=600&auto=format&fit=crop',
    rating: 4.9,
    reviews: 245,
    specialties: ['Deep Tissue', 'Pijat Masuk Angin', 'Kerokan'],
    certification: 'Sertifikasi Terapi Anatomi Otot',
    standbyArea: 'Jakarta Pusat & Jakbar',
    badge: '💪 Tenaga Kuat Mantap',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
    bio: 'Fokus pada pelepasan simpul otot kaku di pundak, pinggang, dan betis. Sangat pas bagi pekerja kantor.',
    available: true,
  },
  {
    id: 't-citra',
    name: 'Terapis Citra Anggraini',
    gender: 'wanita',
    age: 26,
    experience: '5 Tahun',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=600&auto=format&fit=crop',
    rating: 5.0,
    reviews: 280,
    specialties: ['Lulur Tradisional', 'Scrub Herbal', 'Pijat Relaksasi'],
    certification: 'Sertifikat Body Scrub & Aesthetics',
    standbyArea: 'Jakarta Barat & Jaksel',
    badge: '🌿 Ahli Perawatan Kulit',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
    bio: 'Spesialis perawatan lulur rempah pencerah kulit dan pijat pereda stres dengan minyak lavender alami.',
    available: true,
  },
  {
    id: 't-bayu',
    name: 'Terapis Bayu Nugroho',
    gender: 'pria',
    age: 31,
    experience: '8 Tahun',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop',
    rating: 4.9,
    reviews: 220,
    specialties: ['Reflexology Kaki', 'Punggung Kaku', 'Shiatsu'],
    certification: 'Penyehat Tradisional Akupresur',
    standbyArea: 'Jakarta Selatan & Jaktim',
    badge: '🏅 Senior Therapist',
    badgeColor: 'bg-amber-100 text-amber-900 border-amber-200',
    bio: 'Mengetahui persis titik saraf telapak kaki dan punggung. Sangat efektif untuk mengatasi insomnia.',
    available: true,
  },
  {
    id: 't-dewi',
    name: 'Terapis Dewi Kartika',
    gender: 'wanita',
    age: 28,
    experience: '6 Tahun',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop',
    rating: 5.0,
    reviews: 298,
    specialties: ['Full Body Massage', 'Totok Wajah', 'Refleksi'],
    certification: 'Certified Wellness Spa Professional',
    standbyArea: 'Jakarta Pusat & Jakut (PIK, Kelapa Gading)',
    badge: '⭐ Paling Sopan & Rapi',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    bio: 'Sentuhan pijatan lembut namun bertekanan merata. Sangat disukai pelanggan hotel berbintang.',
    available: true,
  },
  {
    id: 't-dimas',
    name: 'Terapis Dimas Saputra',
    gender: 'pria',
    age: 30,
    experience: '7 Tahun',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=600&auto=format&fit=crop',
    rating: 4.9,
    reviews: 195,
    specialties: ['Pijat Pegal Linu', 'Kerokan Tradisional', 'Refleksi'],
    certification: 'Sertifikat Pijat Kebugaran Jasmani',
    standbyArea: 'Jakarta Barat & Jakpus',
    badge: '🔥 Ahli Masuk Angin',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
    bio: 'Ahli dalam mengatasi keluhan badan meriang, kembung, dan pegal berat setelah lembur atau luar kota.',
    available: true,
  },
  {
    id: 't-sarah',
    name: 'Terapis Sarah Lestari',
    gender: 'wanita',
    age: 25,
    experience: '4 Tahun',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=600&auto=format&fit=crop',
    rating: 4.9,
    reviews: 185,
    specialties: ['Aromaterapi Relaksasi', 'Totok Kepala', 'Refleksi'],
    certification: 'Sertifikat Relaksasi & Reflexology',
    standbyArea: 'Jakarta Selatan (Kemang, Simatupang)',
    badge: '🌸 Sentuhan Menenangkan',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200',
    bio: 'Menghadirkan suasana spa hotel menenangkan dengan minyak aromaterapi esensial dan totok kepala pereda stres.',
    available: true,
  },
  {
    id: 't-hendra',
    name: 'Terapis Hendra Wijaya',
    gender: 'pria',
    age: 32,
    experience: '9 Tahun',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=600&auto=format&fit=crop',
    rating: 5.0,
    reviews: 340,
    specialties: ['Deep Muscle Therapy', 'Sport Massage', 'Spine Relief'],
    certification: 'Master Penyehat Tradisional & Sport Recovery',
    standbyArea: 'Jakarta Selatan & Jakpus',
    badge: '👑 Master Therapist (9 Thn)',
    badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
    bio: 'Senior terapis berpengalaman tinggi menangani otot tegang atlet, eksekutif bisnis, dan tamu hotel bintang 5.',
    available: true,
  },
];

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isSlidePaused, setIsSlidePaused] = useState(false);
  const [selectedDistrict, setSelectedDistrict] = useState<'selatan' | 'pusat' | 'barat' | 'utara' | 'timur'>('selatan');

  // Therapist Filter State
  const [therapistFilter, setTherapistFilter] = useState<'all' | 'wanita' | 'pria'>('all');
  const [selectedTherapistForModal, setSelectedTherapistForModal] = useState<TherapistItem | null>(null);

  // Booking Form State
  const [bookingName, setBookingName] = useState('');
  const [bookingService, setBookingService] = useState('Traditional Body Massage');
  const [bookingDuration, setBookingDuration] = useState('90 Menit');
  const [bookingTherapist, setBookingTherapist] = useState('Terapis Wanita (Rekomendasi Admin)');
  const [bookingArea, setBookingArea] = useState('Jakarta Selatan');
  const [bookingTime, setBookingTime] = useState('Sekarang / Secepatnya');
  const [bookingAddress, setBookingAddress] = useState('');
  const [selectedAdminId, setSelectedAdminId] = useState<'siska' | 'erik'>('siska');
  const [formCopied, setFormCopied] = useState(false);

  // FAQ Accordion State
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Slide Auto-play timer
  useEffect(() => {
    if (isSlidePaused) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [isSlidePaused]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  // Helper WhatsApp Link Generator
  const getAdminWaUrl = (adminPhone: string, text: string) => {
    return `https://api.whatsapp.com/send?phone=${adminPhone}&text=${encodeURIComponent(text)}`;
  };

  const getDefaultAdminWaUrl = (text: string) => {
    const admin = ADMIN_LIST.find((a) => a.id === selectedAdminId) || ADMIN_LIST[0];
    return getAdminWaUrl(admin.phone, text);
  };

  const getFormMessage = () => {
    return (
      `*FORMULIR ORDER PIJAT PANGGILAN - DAYDREAMS MASSAGE*\n` +
      `*PT. DAYDREAMS MASSAGE SEHAT JAKARTA*\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 *Nama:* ${bookingName || '(Belum diisi)'}\n` +
      `💆‍♂️ *Layanan:* ${bookingService}\n` +
      `⏱️ *Durasi:* ${bookingDuration}\n` +
      `👥 *Pilihan Terapis:* ${bookingTherapist}\n` +
      `📍 *Wilayah:* ${bookingArea}\n` +
      `🏢 *Lokasi / Hotel & Kamar:* ${bookingAddress || '(Belum diisi)'}\n` +
      `🕒 *Waktu Panggilan:* ${bookingTime}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `Halo Admin, mohon info ketersediaan terapis & total biayanya. Terima kasih!`
    );
  };

  const handleCopyBooking = () => {
    navigator.clipboard.writeText(getFormMessage());
    setFormCopied(true);
    setTimeout(() => setFormCopied(false), 2500);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const admin = ADMIN_LIST.find((a) => a.id === selectedAdminId) || ADMIN_LIST[0];
    const url = getAdminWaUrl(admin.phone, getFormMessage());
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans antialiased selection:bg-amber-500 selection:text-white">
      {/* 1. TOP 24-HOUR VIP DISPATCH BANNER */}
      <div id="top-announcement" className="bg-slate-950 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
              24 JAM NONSTOP
            </span>
            <span className="hidden sm:inline font-medium">
              PT. DAYDREAMS MASSAGE SEHAT JAKARTA • Pijat Panggilan Hotel, Apartemen & Rumah
            </span>
            <span className="sm:hidden font-medium">Pijat Panggilan Jakarta 24 Jam</span>
          </div>

          <div className="flex items-center space-x-3 text-xs">
            <span className="text-slate-400 hidden md:inline">Admin Online:</span>
            <button
              onClick={() => setAdminModalOpen(true)}
              className="inline-flex items-center text-amber-400 hover:text-amber-300 font-semibold"
            >
              <Phone className="w-3 h-3 mr-1 text-emerald-400" />
              <span>SISKA & Mr.Erik</span>
              <span className="ml-1 text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded">Chat</span>
            </button>
            <span className="text-slate-600">|</span>
            <span className="text-emerald-400 flex items-center font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 inline-block"></span> Terapis Ready
            </span>
          </div>
        </div>
      </div>

      {/* 2. PRIMARY STICKY NAVBAR */}
      <header id="main-header" className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo Brand with Real Image */}
            <a href="#beranda" className="flex items-center space-x-3 group text-decoration-none">
              <img
                src="https://daydreamsmassagejakarta.com/wp-content/uploads/2026/09/Logo-Daydreams-Jakarta-Massage-2.webp"
                alt="Daydreams Massage Jakarta - PT. DAYDREAMS MASSAGE SEHAT JAKARTA"
                className="h-12 w-auto max-w-[200px] object-contain transition-transform duration-200 group-hover:scale-105"
                onError={(e) => {
                  // Graceful fallback if image URL fails
                  const target = e.currentTarget;
                  target.style.display = 'none';
                  const fallback = document.getElementById('logo-text-fallback');
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              <div id="logo-text-fallback" style={{ display: 'none' }} className="flex items-center space-x-2">
                <div className="w-11 h-11 rounded-xl bg-slate-950 flex items-center justify-center text-amber-400 shadow">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xl font-bold font-serif text-slate-950 block leading-tight">
                    Daydreams<span className="text-amber-500">.</span>
                  </span>
                  <span className="text-[10px] font-semibold tracking-wider uppercase text-slate-500 block">
                    PT. Daydreams Massage Sehat Jakarta
                  </span>
                </div>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-6 text-xs font-semibold text-slate-700">
              <a href="#beranda" className="hover:text-amber-600 transition-colors py-1">Beranda</a>
              <a href="#admin-section" className="hover:text-amber-600 transition-colors py-1 text-emerald-600 font-bold flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1 animate-ping"></span>
                Admin 24 Jam
              </a>
              <a href="#layanan" className="hover:text-amber-600 transition-colors py-1">Layanan</a>
              <a href="#terapis" className="hover:text-amber-600 transition-colors py-1 text-amber-600 font-bold flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mr-1"></span>
                Terapis Ready
              </a>
              <a href="#keunggulan" className="hover:text-amber-600 transition-colors py-1">Keunggulan</a>
              <a href="#area-layanan" className="hover:text-amber-600 transition-colors py-1">Area Jakarta</a>
              <a href="#tarif" className="hover:text-amber-600 transition-colors py-1">Tarif</a>
              <a href="#testimoni" className="hover:text-amber-600 transition-colors py-1">Testimoni</a>
              <a href="#tentang-kami" className="hover:text-amber-600 transition-colors py-1">Profil PT</a>
              <a href="#booking" className="hover:text-amber-600 transition-colors py-1">Cara Order</a>
            </nav>

            {/* CTA Buttons */}
            <div className="flex items-center space-x-2.5">
              <button
                onClick={() => setAdminModalOpen(true)}
                className="hidden sm:inline-flex items-center space-x-1.5 px-4 py-2.5 rounded-full text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5"
              >
                <MessageCircle className="w-4 h-4 text-white" />
                <span>Pilih Admin WhatsApp</span>
              </button>

              {/* Mobile Hamburger Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2.5 rounded-xl text-slate-700 hover:bg-slate-100 focus:outline-none"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-slate-900 text-white px-4 pt-3 pb-6 space-y-2 border-b border-slate-800 shadow-2xl animate-in slide-in-from-top-2">
            <a onClick={() => setMobileMenuOpen(false)} href="#beranda" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Beranda</a>
            <a onClick={() => { setMobileMenuOpen(false); setAdminModalOpen(true); }} className="block py-2 px-3 rounded-lg text-sm bg-emerald-950/60 text-emerald-300 font-bold border border-emerald-800/40">
              💬 Admin Spa Online (SISKA & Mr.Erik)
            </a>
            <a onClick={() => setMobileMenuOpen(false)} href="#layanan" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Menu Layanan Pijat</a>
            <a onClick={() => setMobileMenuOpen(false)} href="#terapis" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800 text-amber-300 font-semibold flex items-center">
              <span className="w-2 h-2 rounded-full bg-amber-400 mr-2"></span>
              Terapis Siap Panggil (Pria & Wanita)
            </a>
            <a onClick={() => setMobileMenuOpen(false)} href="#keunggulan" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Keunggulan Layanan</a>
            <a onClick={() => setMobileMenuOpen(false)} href="#area-layanan" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Area Jangkauan Jakarta</a>
            <a onClick={() => setMobileMenuOpen(false)} href="#tarif" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Daftar Harga & Paket</a>
            <a onClick={() => setMobileMenuOpen(false)} href="#tentang-kami" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Profil PT. Daydreams Massage</a>
            <a onClick={() => setMobileMenuOpen(false)} href="#testimoni" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Ulasan & Testimoni</a>
            <a onClick={() => setMobileMenuOpen(false)} href="#booking" className="block py-2 px-3 rounded-lg text-sm hover:bg-slate-800">Formulir Booking Cepat</a>

            <div className="pt-3 border-t border-slate-800 space-y-2">
              <p className="text-[11px] text-slate-400">Hubungi Admin Langsung:</p>
              <div className="grid grid-cols-2 gap-2">
                <a
                  href={getAdminWaUrl('62895629139936', 'Halo Admin SISKA, saya ingin tanya terapis pijat yang ready.')}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center py-2 px-3 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow"
                >
                  <Phone className="w-3.5 h-3.5 mr-1.5" /> SISKA
                </a>
                <a
                  href={getAdminWaUrl('6285217344735', 'Halo Admin Mr.Erik, saya ingin tanya terapis pijat yang ready.')}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center py-2 px-3 rounded-lg bg-amber-600 text-white text-xs font-bold shadow"
                >
                  <Phone className="w-3.5 h-3.5 mr-1.5" /> Mr.Erik
                </a>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* 3. DEDICATED HERO SECTION WITH SLIDE IMAGE CAROUSEL */}
      <section
        id="beranda"
        className="relative bg-slate-950 text-white overflow-hidden"
        onMouseEnter={() => setIsSlidePaused(true)}
        onMouseLeave={() => setIsSlidePaused(false)}
      >
        {/* Background Image Carousel Slides */}
        <div className="relative min-h-[580px] sm:min-h-[640px] lg:min-h-[700px] flex items-center">
          {HERO_SLIDES.map((slide, index) => {
            const isActive = index === currentSlide;
            return (
              <div
                key={slide.id}
                className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                  isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
                }`}
              >
                {/* Background Image with Zoom Effect */}
                <img
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-10000"
                />
                {/* Rich Gradient Overlay for ultimate text legibility */}
                <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-950/85 to-slate-900/60"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/60"></div>
              </div>
            );
          })}

          {/* Hero Foreground Content */}
          <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 w-full">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Left Text Column */}
              <div className="lg:col-span-8 space-y-6 text-center lg:text-left">
                {/* Badge */}
                <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-900/80 border border-amber-500/40 text-xs font-semibold tracking-wide text-amber-400 backdrop-blur-md shadow-lg">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block"></span>
                  <span>{HERO_SLIDES[currentSlide].tag}</span>
                </div>

                {/* Main H1 Headline */}
                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold font-serif tracking-tight leading-tight text-white drop-shadow-md">
                  {HERO_SLIDES[currentSlide].title}
                </h1>

                {/* Subheadline & PT Profile */}
                <p className="text-sm sm:text-base lg:text-lg text-slate-200 max-w-2xl leading-relaxed">
                  {HERO_SLIDES[currentSlide].subtitle}
                </p>

                {/* Company Tagline */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md max-w-2xl text-xs sm:text-sm text-amber-200/90 flex items-start space-x-2.5">
                  <Sparkles className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                  <span>
                    <strong>PT. DAYDREAMS MASSAGE SEHAT JAKARTA</strong> — Memberikan kenyamanan, privasi, dan relaksasi total bagi pelanggan tanpa harus keluar rumah.
                  </span>
                </div>

                {/* Trust Points Badges */}
                <div className="grid grid-cols-3 gap-2.5 max-w-lg pt-1">
                  <div className="bg-slate-900/75 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-left">
                    <div className="text-amber-400 font-bold text-xs flex items-center">
                      <ShieldCheck className="w-3.5 h-3.5 mr-1 text-amber-400" /> Terapis Ahli
                    </div>
                    <p className="text-[10px] text-slate-300">Pria & Wanita Pilihan</p>
                  </div>
                  <div className="bg-slate-900/75 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-left">
                    <div className="text-emerald-400 font-bold text-xs flex items-center">
                      <Clock className="w-3.5 h-3.5 mr-1 text-emerald-400" /> 30–45 Menit
                    </div>
                    <p className="text-[10px] text-slate-300">Tiba Cepat di Lokasi</p>
                  </div>
                  <div className="bg-slate-900/75 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-left">
                    <div className="text-blue-400 font-bold text-xs flex items-center">
                      <Star className="w-3.5 h-3.5 mr-1 text-blue-400" /> 100% Privat
                    </div>
                    <p className="text-[10px] text-slate-300">Aman & Terpercaya</p>
                  </div>
                </div>

                {/* Hero CTAs */}
                <div className="pt-3 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5">
                  <button
                    onClick={() => setAdminModalOpen(true)}
                    className="w-full sm:w-auto inline-flex items-center justify-center px-7 py-3.5 rounded-full text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xl shadow-emerald-600/30 transition-all transform hover:-translate-y-0.5"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    <span>Panggil Terapis via WhatsApp</span>
                  </button>

                  <a
                    href="#layanan"
                    className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3.5 rounded-full text-sm font-semibold text-slate-200 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 backdrop-blur-md transition-all"
                  >
                    <span>Lihat Menu & Tarif</span>
                  </a>
                </div>
              </div>

              {/* Right Column: Interactive Quick Admin Dispatch Box */}
              <div className="lg:col-span-4">
                <div className="bg-slate-900/90 backdrop-blur-xl p-6 rounded-3xl border border-slate-700/80 shadow-2xl space-y-4 text-left">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center space-x-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="text-xs font-bold text-white uppercase tracking-wider">Admin Spa Online</span>
                    </div>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
                      Buka 24 Jam
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    Silakan pilih admin untuk memesan atau konsultasi foto terapis yang standby di dekat lokasi Anda:
                  </p>

                  {/* Admin 1 (SISKA) Card */}
                  <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 hover:border-pink-500/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-pink-500 to-rose-600 flex items-center justify-center text-white font-bold text-xs shadow">
                          SK
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center">
                            Admin 1 (SISKA)
                            <span className="ml-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
                          </div>
                          <div className="text-[11px] text-amber-400 font-mono">+62 895-6291-39936</div>
                        </div>
                      </div>
                      <a
                        href={getAdminWaUrl('62895629139936', 'Halo Admin SISKA, saya ingin panggil terapis pijat ke lokasi saya sekarang.')}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow transition-transform active:scale-95"
                      >
                        <MessageCircle className="w-3 h-3" />
                        <span>Chat</span>
                      </a>
                    </div>
                    <p className="text-[10px] text-slate-400">Siap melayani booking hotel & apartemen Jakarta</p>
                  </div>

                  {/* Admin 2 (Mr.Erik) Card */}
                  <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 hover:border-amber-500/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 font-bold text-xs shadow">
                          EK
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center">
                            Admin 2 (Mr.Erik)
                            <span className="ml-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
                          </div>
                          <div className="text-[11px] text-amber-400 font-mono">+62 852-1734-4735</div>
                        </div>
                      </div>
                      <a
                        href={getAdminWaUrl('6285217344735', 'Halo Admin Mr.Erik, saya ingin panggil terapis pijat ke lokasi saya sekarang.')}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow transition-transform active:scale-95"
                      >
                        <MessageCircle className="w-3 h-3" />
                        <span>Chat</span>
                      </a>
                    </div>
                    <p className="text-[10px] text-slate-400">Siap melayani booking 24 jam & terapis pria/wanita</p>
                  </div>

                  <a
                    href="#booking"
                    className="w-full block text-center py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                  >
                    Atau Isi Formulir Pemesanan Cepat &darr;
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Carousel Arrows & Dot Indicators */}
          <div className="absolute z-30 bottom-6 left-1/2 -translate-x-1/2 flex items-center space-x-3 bg-slate-950/80 px-4 py-2 rounded-full border border-slate-800 backdrop-blur-md">
            <button
              onClick={prevSlide}
              aria-label="Previous slide"
              className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center space-x-2">
              {HERO_SLIDES.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  aria-label={`Go to slide ${idx + 1}`}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    currentSlide === idx ? 'w-6 bg-amber-400' : 'w-2 bg-slate-600 hover:bg-slate-400'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={nextSlide}
              aria-label="Next slide"
              className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 4. DEDICATED SECTION: ADMIN SPA ONLINE (24 JAM) */}
      <section id="admin-section" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-2 max-w-2xl mx-auto">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>CUSTOMER SERVICE 24 JAM</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold font-serif">
              Admin Spa Online (24 Jam)
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Silakan pilih admin untuk memesan atau konsultasi terapis yang ready:
            </p>
          </div>

          {/* Dual Admin Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {/* Admin 1 (SISKA) */}
            <div className="bg-gradient-to-b from-slate-800/90 to-slate-950 p-6 sm:p-8 rounded-3xl border-2 border-slate-700/80 hover:border-pink-500/50 shadow-xl space-y-4 transition-all hover:shadow-2xl">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-pink-500 via-rose-500 to-rose-600 flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    SK
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-pink-400 bg-pink-950/60 px-2 py-0.5 rounded-full border border-pink-800">
                      Customer Service 1
                    </span>
                    <h3 className="text-xl font-bold font-serif text-white mt-1">Admin 1 (SISKA)</h3>
                    <p className="text-xs text-emerald-400 flex items-center mt-0.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-ping"></span>
                      Online Sekarang (24 Jam)
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1 text-xs">
                <div className="text-slate-400">Nomor WhatsApp Resmi:</div>
                <div className="text-amber-400 font-mono font-bold text-base">+62 895-6291-39936</div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Melayani booking pijat panggilan hotel, apartemen, dan perumahan di Jakarta. Konsultasi keluhan pegal, pilihan terapis wanita/pria, dan estimasi waktu sampai.
              </p>

              <div className="pt-2">
                <a
                  href={getAdminWaUrl('62895629139936', 'Halo Admin SISKA, saya ingin order terapis pijat panggilan Daydreams Massage sekarang.')}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full flex items-center justify-center py-3.5 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all transform hover:-translate-y-0.5"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  <span>Chat Admin SISKA (+62 895-6291-39936)</span>
                </a>
              </div>
            </div>

            {/* Admin 2 (Mr.Erik) */}
            <div className="bg-gradient-to-b from-slate-800/90 to-slate-950 p-6 sm:p-8 rounded-3xl border-2 border-slate-700/80 hover:border-amber-500/50 shadow-xl space-y-4 transition-all hover:shadow-2xl">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center text-slate-950 font-bold text-xl shadow-lg">
                    EK
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-800">
                      Customer Service 2
                    </span>
                    <h3 className="text-xl font-bold font-serif text-white mt-1">Admin 2 (Mr.Erik)</h3>
                    <p className="text-xs text-emerald-400 flex items-center mt-0.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-ping"></span>
                      Online Sekarang (24 Jam)
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1 text-xs">
                <div className="text-slate-400">Nomor WhatsApp Resmi:</div>
                <div className="text-amber-400 font-mono font-bold text-base">+62 852-1734-4735</div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Melayani booking express 24 jam nonstop ke seluruh penjuru Jakarta. Fast dispatch 30-45 menit tiba di kamar hotel Anda dengan perlengkapan lengkap.
              </p>

              <div className="pt-2">
                <a
                  href={getAdminWaUrl('6285217344735', 'Halo Admin Mr.Erik, saya ingin order terapis pijat panggilan Daydreams Massage sekarang.')}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full flex items-center justify-center py-3.5 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all transform hover:-translate-y-0.5"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  <span>Chat Admin Mr.Erik (+62 852-1734-4735)</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. TENTANG KAMI & PROFIL PT */}
      <section id="tentang-kami" className="py-12 sm:py-16 px-4 sm:px-8 bg-white border-b border-slate-100">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-5">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-semibold">
                <Award className="w-3.5 h-3.5 text-amber-600 mr-1" />
                <span>LEGALITAS & KOMITMEN LAYANAN</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900 leading-tight">
                Daydreams Massage Jakarta <br />
                <span className="text-amber-600">PT. DAYDREAMS MASSAGE SEHAT JAKARTA</span>
              </h2>

              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                <strong>Memberikan kenyamanan, privasi, dan relaksasi total bagi pelanggan tanpa harus keluar rumah.</strong> Menghadirkan terapis profesional bersertifikat langsung ke kamar hotel, apartemen mewah, dan hunian pribadi Anda di seluruh kawasan Jakarta.
              </p>

              <div className="space-y-3 text-xs sm:text-sm text-slate-700 pt-1">
                <div className="flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>100% Layanan Bersih & Profesional:</strong> Menjunjung tinggi etika kesopanan dan menolak keras segala bentuk permintaan di luar standar terapi kebugaran kesehatan.</span>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Terapis Bersertifikat Resmi:</strong> Seluruh tim terapis kami telah melalui pelatihan ketat pemijatan anatomi, sopan santun, dan higienitas.</span>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Privasi Tamu Dijamin Rapat:</strong> Identitas, alamat kamar hotel, atau nomor hunian Anda dijaga kerahasiaannya tanpa kompromi.</span>
                </div>
              </div>

              <div className="pt-2 flex items-center space-x-3">
                <button
                  onClick={() => setAdminModalOpen(true)}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors inline-flex items-center"
                >
                  <Phone className="w-3.5 h-3.5 mr-2 text-amber-400" />
                  <span>Hubungi Admin Resmi</span>
                </button>
                <a
                  href="#area-layanan"
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200 transition-colors"
                >
                  Cek Area Jangkauan
                </a>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
                <img
                  src="https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=900&auto=format&fit=crop"
                  alt="Relaksasi Spa Hotel PT Daydreams Massage Sehat Jakarta"
                  className="w-full h-80 sm:h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent flex flex-col justify-end p-6 text-white">
                  <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
                    Jaminan Kepuasan & Kenyamanan
                  </span>
                  <h4 className="text-lg font-bold font-serif mt-1">Standar Bintang 5 Langsung di Tempat Anda</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Dilengkapi minyak esensial aromaterapi impor, kain/sprei baru yang steril, serta aromaterapi penenang pikiran.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. KEUNGGULAN SECTION */}
      <section id="keunggulan" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-50">
        <div className="max-w-6xl mx-auto text-center space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-700 bg-amber-100 px-3 py-1 rounded-full">
            Keunggulan Kami
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
            Mengapa Memilih Daydreams Massage Jakarta?
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl mx-auto">
            Kenyamanan, kebersihan, dan privasi Anda adalah jaminan utama kami.
          </p>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2 font-serif">Terapis Terlatih & Bersertifikat</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Menguasai titik saraf tubuh dan teknik pemijatan anatomis. Sopan, ramah, dan berpengalaman di hotel bintang Jakarta.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center mb-4">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2 font-serif">Buka 24 Jam Nonstop</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Siap meluncur tengah malam atau dini hari setelah perjalanan jauh atau lembur kantor. Respon cepat oleh Admin SISKA & Mr.Erik.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center mb-4">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base mb-2 font-serif">Bebas Pilih Terapis & Privasi</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Pilihan terapis pria atau wanita sesuai kenyamanan Anda. Data alamat dan identitas dijamin 100% rahasia dan aman.
            </p>
          </div>
        </div>
      </section>

      {/* 7. LAYANAN SECTION - DENGAN GAMBAR LENGKAP */}
      <section id="layanan" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-50 border-t border-slate-200">
        <div className="max-w-6xl mx-auto text-center space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-200">
            Pilihan Menu Lengkap
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
            Daftar Layanan Pijat Panggilan Jakarta
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto">
            Setiap sesi dipandu oleh terapis terlatih dengan minyak aromaterapi esensial hangat, matras/kain higienis steril, dan teknik pemijatan anatomis.
          </p>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {MASSAGE_SERVICES.map((service) => (
            <div
              key={service.id}
              className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              {/* Image & Badges */}
              <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent"></div>

                {/* Badge Category */}
                <div className="absolute top-3 left-3">
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full shadow-sm border backdrop-blur-sm ${service.badgeColor}`}>
                    {service.badge}
                  </span>
                </div>

                {/* Duration Overlay */}
                <div className="absolute bottom-3 left-3 flex items-center space-x-1.5 text-white text-xs font-medium bg-slate-950/70 px-2.5 py-1 rounded-lg backdrop-blur-sm">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{service.duration}</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 font-serif group-hover:text-amber-600 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Focus Area */}
                  <div className="mt-3 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="font-semibold text-slate-700">Area Fokus:</span> {service.focusArea}
                  </div>

                  {/* Benefits Checklist */}
                  <ul className="mt-3.5 space-y-1.5 text-xs text-slate-600">
                    {service.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Footer & Price */}
                <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-medium">Tarif Mulai</span>
                    <span className="font-bold text-emerald-600 text-base sm:text-lg">{service.price}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {
                        setBookingService(service.title);
                        const bookingEl = document.getElementById('booking');
                        if (bookingEl) bookingEl.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="px-3 py-2 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors"
                      title="Isi di Formulir"
                    >
                      Pilih
                    </button>
                    <button
                      onClick={() => {
                        setBookingService(service.title);
                        setAdminModalOpen(true);
                      }}
                      className="inline-flex items-center space-x-1 px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 shadow hover:shadow-md transition-all"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-white" />
                      <span>Order WA</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7B. GRID TERAPIS SIAP PANGGIL 24 JAM */}
      <section id="terapis" className="py-12 sm:py-16 px-4 sm:px-8 bg-white border-t border-slate-200">
        <div className="max-w-6xl mx-auto text-center space-y-2 mb-8">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-200">
            Terapis Bersertifikat Standby 24 Jam
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
            Pilihan Terapis Profesional Pria & Wanita
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto">
            Seluruh terapis kami berpenampilan bersih, sopan, menguasai teknik urut profesional, dan mematuhi SOP higienitas ketat. Pilih terapis favorit Anda:
          </p>

          {/* Filter Tab: Semua / Wanita / Pria */}
          <div className="flex justify-center items-center space-x-2 pt-4">
            <button
              onClick={() => setTherapistFilter('all')}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                therapistFilter === 'all'
                  ? 'bg-slate-950 text-white shadow-md'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Semua Terapis ({THERAPISTS_LIST.length})
            </button>
            <button
              onClick={() => setTherapistFilter('wanita')}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                therapistFilter === 'wanita'
                  ? 'bg-pink-600 text-white shadow-md'
                  : 'bg-pink-50 text-pink-700 hover:bg-pink-100'
              }`}
            >
              👩 Terapis Wanita ({THERAPISTS_LIST.filter(t => t.gender === 'wanita').length})
            </button>
            <button
              onClick={() => setTherapistFilter('pria')}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                therapistFilter === 'pria'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
              }`}
            >
              👨 Terapis Pria ({THERAPISTS_LIST.filter(t => t.gender === 'pria').length})
            </button>
          </div>
        </div>

        {/* Therapists Grid */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {THERAPISTS_LIST.filter(t => therapistFilter === 'all' || t.gender === therapistFilter).map((therapist) => (
            <div
              key={therapist.id}
              className="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Photo & Online Status */}
                <div className="relative aspect-[4/5] overflow-hidden bg-slate-200">
                  <img
                    src={therapist.image}
                    alt={therapist.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>

                  {/* Standby Indicator */}
                  <div className="absolute top-3 left-3 bg-emerald-950/85 text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-emerald-700 flex items-center space-x-1.5 backdrop-blur-sm">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Ready Standby</span>
                  </div>

                  {/* Gender & Age */}
                  <div className="absolute top-3 right-3">
                    <span className="text-[10px] font-semibold bg-slate-900/80 text-white px-2 py-0.5 rounded-md backdrop-blur-sm">
                      {therapist.gender === 'wanita' ? 'Wanita' : 'Pria'}, {therapist.age} Thn
                    </span>
                  </div>

                  {/* Rating & Reviews overlay at bottom of photo */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs">
                    <div className="flex items-center space-x-1 bg-black/50 px-2 py-1 rounded-lg backdrop-blur-sm">
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      <span className="font-bold">{therapist.rating.toFixed(1)}</span>
                      <span className="text-[10px] text-slate-300">({therapist.reviews})</span>
                    </div>
                    <span className="text-[10px] font-medium bg-amber-500/90 text-slate-950 px-2 py-0.5 rounded font-mono font-bold">
                      {therapist.experience} Exp
                    </span>
                  </div>
                </div>

                {/* Therapist Info */}
                <div className="p-4 space-y-2.5">
                  <div className="flex items-start justify-between">
                    <h3 className="font-bold text-slate-900 text-base font-serif group-hover:text-amber-600 transition-colors">
                      {therapist.name}
                    </h3>
                  </div>

                  {/* Special Badge */}
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border inline-block ${therapist.badgeColor}`}>
                      {therapist.badge}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {therapist.bio}
                  </p>

                  {/* Certification */}
                  <div className="flex items-center text-[10px] text-emerald-700 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-100">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 mr-1 flex-shrink-0" />
                    <span className="truncate font-medium">{therapist.certification}</span>
                  </div>

                  {/* Standby Location */}
                  <div className="flex items-center text-[10px] text-slate-500">
                    <MapPin className="w-3.5 h-3.5 text-amber-500 mr-1 flex-shrink-0" />
                    <span className="truncate">Standby: {therapist.standbyArea}</span>
                  </div>

                  {/* Specialties Chips */}
                  <div className="flex flex-wrap gap-1 pt-1">
                    {therapist.specialties.map((spec, i) => (
                      <span key={i} className="text-[9px] bg-slate-200/80 text-slate-700 px-1.5 py-0.5 rounded font-medium">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Therapist Card Action */}
              <div className="p-4 pt-2 border-t border-slate-200/80 space-y-2">
                <a
                  href={getAdminWaUrl(
                    '62895629139936',
                    `Halo Admin SISKA, saya ingin memesan jasa *${therapist.name} (${therapist.gender === 'wanita' ? 'Wanita' : 'Pria'})* untuk pijat panggilan ke lokasi saya. Apakah ready?`
                  )}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow transition-all"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-white" />
                  <span>Pesan Terapis (WA)</span>
                </a>

                <button
                  onClick={() => {
                    setBookingTherapist(`${therapist.name} (${therapist.gender === 'wanita' ? 'Wanita' : 'Pria'})`);
                    const bookingEl = document.getElementById('booking');
                    if (bookingEl) bookingEl.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full text-center py-1.5 text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition-colors"
                >
                  Pilih di Form Pemesanan ↓
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Note on Therapists */}
        <div className="max-w-4xl mx-auto mt-8 bg-amber-50 border border-amber-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center flex-shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Punya Preferensi Khusus atau Butuh Rekomendasi Terapis?
              </h4>
              <p className="text-[11px] sm:text-xs text-slate-600">
                Admin SISKA & Mr.Erik siap membantu mencarikan terapis terdekat dengan durasi tiba tercepat.
              </p>
            </div>
          </div>
          <button
            onClick={() => setAdminModalOpen(true)}
            className="flex-shrink-0 px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 shadow"
          >
            Konsultasi dengan Admin
          </button>
        </div>
      </section>

      {/* 8. AREA COVERAGE JAKARTA 24 JAM */}
      <section id="area-layanan" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-950 text-white">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-400 bg-amber-950 px-3 py-1 rounded-full border border-amber-800">
              Jangkauan Layanan Cepat
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif">
              Coverage Area Seluruh DKI Jakarta 24 Jam
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
              Klik wilayah di bawah untuk melihat cakupan daerah dan estimasi kedatangan terapis.
            </p>
          </div>

          {/* District Selector Tabs */}
          <div className="flex flex-wrap justify-center gap-2">
            <button
              onClick={() => setSelectedDistrict('selatan')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedDistrict === 'selatan'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Jakarta Selatan
            </button>
            <button
              onClick={() => setSelectedDistrict('pusat')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedDistrict === 'pusat'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Jakarta Pusat
            </button>
            <button
              onClick={() => setSelectedDistrict('barat')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedDistrict === 'barat'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Jakarta Barat
            </button>
            <button
              onClick={() => setSelectedDistrict('utara')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedDistrict === 'utara'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Jakarta Utara
            </button>
            <button
              onClick={() => setSelectedDistrict('timur')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedDistrict === 'timur'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Jakarta Timur
            </button>
          </div>

          {/* District Detail Card */}
          <div className="bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-800 text-left max-w-3xl mx-auto">
            {selectedDistrict === 'selatan' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-amber-400" />
                    Jakarta Selatan (Zona Fast Dispatch 30 Menit)
                  </h4>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded font-semibold">
                    Standby Terdekat
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Kawasan Hotel & Apartemen:</strong> SCBD Sudirman, Senopati, Kemang, Kuningan (Rasuna Said & Mega Kuningan), Gatot Subroto, Kebayoran Baru, Blok M, Gandaria, Pondok Indah, Cilandak, TB Simatupang, Tebet, Pancoran, Kalibata.
                </p>
              </div>
            )}

            {selectedDistrict === 'pusat' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-amber-400" />
                    Jakarta Pusat (Pusat Bisnis & Hotel Bintang 5)
                  </h4>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded font-semibold">
                    30 Menit Tiba
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Kawasan Hotel & Apartemen:</strong> MH Thamrin, Bundaran HI, Menteng, Tanah Abang, Senayan, Gambir, Cikini, Kemayoran, Salemba, Bendungan Hilir (Benhil), Pasar Baru.
                </p>
              </div>
            )}

            {selectedDistrict === 'barat' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-amber-400" />
                    Jakarta Barat
                  </h4>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded font-semibold">
                    35 Menit Tiba
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Kawasan Hotel & Apartemen:</strong> Tomang, Slipi, Grogol, Tanjung Duren, Kebon Jeruk, Puri Indah, Taman Anggrek, Central Park, Palmerah, Meruya, Kembangan.
                </p>
              </div>
            )}

            {selectedDistrict === 'utara' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-amber-400" />
                    Jakarta Utara
                  </h4>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded font-semibold">
                    35–45 Menit Tiba
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Kawasan Hotel & Apartemen:</strong> Pluit, Pantai Indah Kapuk (PIK 1 & PIK 2), Kelapa Gading, Sunter, Ancol, Pademangan, Mangga Dua, Danau Sunter.
                </p>
              </div>
            )}

            {selectedDistrict === 'timur' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-base flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-amber-400" />
                    Jakarta Timur
                  </h4>
                  <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 rounded font-semibold">
                    35–45 Menit Tiba
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong>Kawasan Hotel & Apartemen:</strong> Rawamangun, Cawang, Matraman, Jatinegara, Duren Sawit, Pulomas, Pulo Gadung, Cibubur, Halim Perdanakusuma.
                </p>
              </div>
            )}

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-400">Panggil terapis ke kamar Anda sekarang:</span>
              <button
                onClick={() => setAdminModalOpen(true)}
                className="text-amber-400 font-bold hover:text-amber-300 inline-flex items-center"
              >
                Hubungi Admin Online &rarr;
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 9. TARIF & PAKET HARGA TRANSPARAN */}
      <section id="tarif" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-50">
        <div className="max-w-5xl mx-auto space-y-8 text-center">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-700 bg-amber-100 px-3 py-1 rounded-full">
              Tarif Resmi & Transparan
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
              Biaya Layanan Pijat Panggilan Jakarta
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Tanpa biaya tersembunyi. Sudah termasuk minyak aromaterapi dan tenaga terapis ahli.
            </p>
          </div>

          <div className="overflow-x-auto bg-white rounded-3xl border border-slate-200 shadow-md">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-900 text-white font-semibold">
                <tr>
                  <th className="p-4 sm:p-5">Paket Layanan</th>
                  <th className="p-4 sm:p-5">Durasi Waktu</th>
                  <th className="p-4 sm:p-5">Fasilitas / Manfaat</th>
                  <th className="p-4 sm:p-5">Tarif</th>
                  <th className="p-4 sm:p-5 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr className="hover:bg-slate-50 transition-colors">
                  <td className="p-4 sm:p-5 font-bold text-slate-900">Reflexology & Relaksasi Kaki</td>
                  <td className="p-4 sm:p-5">60 Menit</td>
                  <td className="p-4 sm:p-5 text-slate-500">Titik saraf telapak kaki, betis & totok kepala</td>
                  <td className="p-4 sm:p-5 font-bold text-emerald-600">Rp 175.000</td>
                  <td className="p-4 sm:p-5 text-center">
                    <button
                      onClick={() => {
                        setBookingService('Reflexology & Relaksasi Kaki');
                        setAdminModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                    >
                      Pesan
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50 transition-colors bg-amber-50/40">
                  <td className="p-4 sm:p-5 font-bold text-slate-900">
                    Traditional Body Massage <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded font-normal ml-1">Favorit</span>
                  </td>
                  <td className="p-4 sm:p-5">90 Menit</td>
                  <td className="p-4 sm:p-5 text-slate-500">Full body urut tradisional + minyak aromaterapi</td>
                  <td className="p-4 sm:p-5 font-bold text-emerald-600">Rp 200.000</td>
                  <td className="p-4 sm:p-5 text-center">
                    <button
                      onClick={() => {
                        setBookingService('Traditional Body Massage');
                        setAdminModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                    >
                      Pesan
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50 transition-colors">
                  <td className="p-4 sm:p-5 font-bold text-slate-900">Pijat Masuk Angin + Kerokan</td>
                  <td className="p-4 sm:p-5">90 Menit</td>
                  <td className="p-4 sm:p-5 text-slate-500">Pijat badan + kerokan leher & punggung hangat</td>
                  <td className="p-4 sm:p-5 font-bold text-emerald-600">Rp 225.000</td>
                  <td className="p-4 sm:p-5 text-center">
                    <button
                      onClick={() => {
                        setBookingService('Pijat Masuk Angin + Kerokan');
                        setAdminModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                    >
                      Pesan
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50 transition-colors">
                  <td className="p-4 sm:p-5 font-bold text-slate-900">Deep Tissue Massage / Otot Pegal</td>
                  <td className="p-4 sm:p-5">90 Menit</td>
                  <td className="p-4 sm:p-5 text-slate-500">Tekanan bertenaga urai simpul otot lelah</td>
                  <td className="p-4 sm:p-5 font-bold text-emerald-600">Rp 250.000</td>
                  <td className="p-4 sm:p-5 text-center">
                    <button
                      onClick={() => {
                        setBookingService('Deep Tissue Massage / Otot Pegal');
                        setAdminModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                    >
                      Pesan
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50 transition-colors">
                  <td className="p-4 sm:p-5 font-bold text-slate-900">Paket Lulur & Body Scrub</td>
                  <td className="p-4 sm:p-5">120 Menit</td>
                  <td className="p-4 sm:p-5 text-slate-500">Pijat relaksasi 60m + lulur scrub herbal 60m</td>
                  <td className="p-4 sm:p-5 font-bold text-emerald-600">Rp 275.000</td>
                  <td className="p-4 sm:p-5 text-center">
                    <button
                      onClick={() => {
                        setBookingService('Paket Lulur & Body Scrub');
                        setAdminModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                    >
                      Pesan
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50 transition-colors bg-pink-50/30">
                  <td className="p-4 sm:p-5 font-bold text-slate-900">
                    Couple Massage (2 Orang) <span className="text-[10px] bg-pink-200 text-pink-900 px-1.5 py-0.5 rounded font-normal ml-1">Spesial</span>
                  </td>
                  <td className="p-4 sm:p-5">120 Menit</td>
                  <td className="p-4 sm:p-5 text-slate-500">2 Terapis datang serentak untuk Anda & Pasangan</td>
                  <td className="p-4 sm:p-5 font-bold text-emerald-600">Rp 450.000</td>
                  <td className="p-4 sm:p-5 text-center">
                    <button
                      onClick={() => {
                        setBookingService('Couple Massage (2 Orang)');
                        setAdminModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
                    >
                      Pesan
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 10. TESTIMONI SECTION */}
      <section id="testimoni" className="py-12 sm:py-16 px-4 sm:px-8 bg-white border-t border-slate-100">
        <div className="max-w-6xl mx-auto text-center space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-700 bg-amber-100 px-3 py-1 rounded-full">
            Testimoni Tamu
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
            Ulasan Asli Tamu Hotel & Residen Jakarta
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Kepercayaan lebih dari 1.850+ pelanggan sejak 2021 di kawasan Jabodetabek.
          </p>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-slate-600 italic leading-relaxed">
              "Lagi perjalanan bisnis dan menginap di hotel kawasan SCBD. Panggil jam 23.30 malam lewat Admin SISKA, terapis datang hanya dalam 30 menit. Sopan banget, pijatannya pas, dan langsung pules tidur."
            </p>
            <div className="pt-2 border-t border-slate-200">
              <div className="font-bold text-xs text-slate-900">Bpk. Rian H.</div>
              <div className="text-[10px] text-slate-500">Tamu Hotel Bintang 5, Sudirman Jaksel</div>
            </div>
          </div>

          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-slate-600 italic leading-relaxed">
              "Pesan Couple Massage untuk di apartemen Thamrin sama suami lewat Admin Mr.Erik. Responnya ramah dan cepat. Dua terapis datang tepat waktu dengan seragam rapi dan perlengkapan bersih. Sangat recommended!"
            </p>
            <div className="pt-2 border-t border-slate-200">
              <div className="font-bold text-xs text-slate-900">Ibu Amanda & Suami</div>
              <div className="text-[10px] text-slate-500">Residen Apartemen, Jakarta Pusat</div>
            </div>
          </div>

          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs sm:text-sm text-slate-600 italic leading-relaxed">
              "Badan meriang masuk angin setelah lembur di kantor. Pesan paket pijat + kerokan. Terapisnya paham betul anatomi saraf dan titik pegal punggung. Bangun pagi badan langsung segar enteng."
            </p>
            <div className="pt-2 border-t border-slate-200">
              <div className="font-bold text-xs text-slate-900">Deni S.</div>
              <div className="text-[10px] text-slate-500">Rumah Tinggal, Kebon Jeruk Jakbar</div>
            </div>
          </div>
        </div>
      </section>

      {/* 11. FORMULIR BOOKING OTOMATIS */}
      <section id="booking" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-900 text-white">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-400 bg-amber-950 px-3 py-1 rounded-full border border-amber-800">
              Formulir Reservasi Cepat
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif">
              Pesan Terapis Langsung ke WhatsApp
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Isi data pemesanan di bawah. Sistem akan otomatis membuka WhatsApp Admin pilihan Anda dengan data lengkap.
            </p>
          </div>

          <form onSubmit={handleFormSubmit} className="bg-slate-950 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl space-y-4 text-left">
            {/* Choose Admin Selector */}
            <div className="p-3.5 bg-slate-900 rounded-2xl border border-slate-800">
              <label className="block text-xs font-semibold text-amber-400 mb-2">
                PILIH ADMIN TUJUAN (24 JAM):
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedAdminId('siska')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedAdminId === 'siska'
                      ? 'bg-pink-950/40 border-pink-500 text-white shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold text-white flex items-center">
                    <span className="w-2 h-2 rounded-full bg-pink-500 mr-1.5"></span>
                    Admin 1 (SISKA)
                  </div>
                  <div className="text-[10px] text-amber-400 font-mono mt-0.5">+62 895-6291-39936</div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedAdminId('erik')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedAdminId === 'erik'
                      ? 'bg-amber-950/40 border-amber-500 text-white shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold text-white flex items-center">
                    <span className="w-2 h-2 rounded-full bg-amber-500 mr-1.5"></span>
                    Admin 2 (Mr.Erik)
                  </div>
                  <div className="text-[10px] text-amber-400 font-mono mt-0.5">+62 852-1734-4735</div>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Nama Anda / Pemesan:
                </label>
                <input
                  type="text"
                  value={bookingName}
                  onChange={(e) => setBookingName(e.target.value)}
                  placeholder="Contoh: Bpk. Hendra"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Pilihan Layanan Pijat:
                </label>
                <select
                  value={bookingService}
                  onChange={(e) => setBookingService(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option>Traditional Body Massage</option>
                  <option>Reflexology & Totok Wajah</option>
                  <option>Pijat + Kerokan Masuk Angin</option>
                  <option>Lulur Tradisional & Scrub</option>
                  <option>Deep Tissue / Pijat Otot Berat</option>
                  <option>Couple Massage Package (2 Orang)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Durasi Pemijatan:
                </label>
                <select
                  value={bookingDuration}
                  onChange={(e) => setBookingDuration(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option>60 Menit</option>
                  <option>90 Menit (Direkomendasikan)</option>
                  <option>120 Menit (Full Relaksasi)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Pilihan Terapis:
                </label>
                <select
                  value={bookingTherapist}
                  onChange={(e) => setBookingTherapist(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="Terapis Wanita (Rekomendasi Admin)">👩 Terapis Wanita (Rekomendasi Admin)</option>
                  <option value="Terapis Pria (Rekomendasi Admin)">👨 Terapis Pria (Rekomendasi Admin)</option>
                  <option value="Sepasang Terapis (Couple 2 Orang)">👫 Sepasang Terapis (Couple 2 Orang)</option>
                  <optgroup label="Terapis Wanita Standby">
                    <option value="Terapis Maya Putri (Wanita)">Terapis Maya Putri (Wanita - Top Rated 5.0)</option>
                    <option value="Terapis Citra Anggraini (Wanita)">Terapis Citra Anggraini (Wanita - Lulur & Scrub)</option>
                    <option value="Terapis Dewi Kartika (Wanita)">Terapis Dewi Kartika (Wanita - Totok & Relaksasi)</option>
                    <option value="Terapis Sarah Lestari (Wanita)">Terapis Sarah Lestari (Wanita - Aromaterapi)</option>
                  </optgroup>
                  <optgroup label="Terapis Pria Standby">
                    <option value="Terapis Rian Pratama (Pria)">Terapis Rian Pratama (Pria - Deep Tissue)</option>
                    <option value="Terapis Bayu Nugroho (Pria)">Terapis Bayu Nugroho (Pria - Refleksi Saraf)</option>
                    <option value="Terapis Dimas Saputra (Pria)">Terapis Dimas Saputra (Pria - Masuk Angin & Kerokan)</option>
                    <option value="Terapis Hendra Wijaya (Pria)">Terapis Hendra Wijaya (Pria - Master 9 Thn)</option>
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Wilayah Jakarta:
                </label>
                <select
                  value={bookingArea}
                  onChange={(e) => setBookingArea(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option>Jakarta Selatan</option>
                  <option>Jakarta Pusat</option>
                  <option>Jakarta Barat</option>
                  <option>Jakarta Utara</option>
                  <option>Jakarta Timur</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Nama Hotel / Apartemen & Nomor Kamar:
              </label>
              <input
                type="text"
                value={bookingAddress}
                onChange={(e) => setBookingAddress(e.target.value)}
                placeholder="Contoh: Hotel Ritz Carlton Mega Kuningan, Kamar 1402"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Waktu Kedatangan:
              </label>
              <select
                value={bookingTime}
                onChange={(e) => setBookingTime(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option>Sekarang / Secepatnya (30-45 Menit)</option>
                <option>1 Jam Lagi</option>
                <option>Malam Ini (Pukul 21:00 - 23:00)</option>
                <option>Tengah Malam (Pukul 00:00 - 03:00)</option>
              </select>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                type="submit"
                className="flex-1 flex items-center justify-center py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/30 transition-all transform hover:-translate-y-0.5"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                <span>Kirim Formulir ke WhatsApp Admin</span>
              </button>

              <button
                type="button"
                onClick={handleCopyBooking}
                className="px-4 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center justify-center transition-colors"
              >
                {formCopied ? <Check className="w-4 h-4 mr-1 text-emerald-400" /> : <Copy className="w-4 h-4 mr-1" />}
                <span>{formCopied ? 'Tersalin!' : 'Salin Teks'}</span>
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* 12. FAQ ACCORDION */}
      <section id="faq" className="py-12 sm:py-16 px-4 sm:px-8 bg-slate-50">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="text-center space-y-2 mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-700 bg-amber-100 px-3 py-1 rounded-full">
              Pertanyaan Umum
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
              Frequently Asked Questions (FAQ)
            </h2>
          </div>

          <div className="space-y-3">
            {[
              {
                q: 'Berapa lama estimasi terapis sampai ke hotel atau apartemen saya?',
                a: 'Estimasi waktu kedatangan adalah 30 hingga 45 menit tergantung pada jarak dan kondisi lalu lintas. Kami menempatkan terapis yang standby di setiap penjuru Jakarta (Pusat, Selatan, Barat, Utara, Timur) sehingga waktu respon sangat cepat.',
              },
              {
                q: 'Apakah bisa memilih foto terapis terlebih dahulu?',
                a: 'Bisa. Anda dapat langsung chat ke WhatsApp Admin 1 (SISKA) di +62895629139936 atau Admin 2 (Mr.Erik) di +6285217344735 untuk meminta foto terapis pria atau wanita yang sedang standby siap tugas.',
              },
              {
                q: 'Apakah perlengkapan seperti minyak dan kain sudah disediakan?',
                a: 'Ya, seluruh terapis Daydreams Massage membawa perlengkapan higienis lengkap, termasuk minyak aromaterapi esensial hangat, matras/kain penutup bersih, dan perlengkapan terapi lainnya. Anda hanya tinggal santai di tempat.',
              },
              {
                q: 'Bagaimana metode pembayarannya?',
                a: 'Pembayaran sangat fleksibel dan aman. Anda dapat membayar tunai (cash) langsung kepada terapis setelah sesi selesai, atau via transfer bank / QRIS.',
              },
              {
                q: 'Apakah Daydreams Massage melayani pemesanan tengah malam / dini hari?',
                a: 'Ya! Kami beroperasi 24 jam nonstop setiap hari termasuk akhir pekan dan hari libur nasional. Hubungi admin kami kapan saja Anda membutuhkan relaksasi.',
              },
            ].map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="bg-white rounded-2xl border border-slate-200 overflow-hidden transition-shadow shadow-sm"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between font-bold text-sm text-slate-900 hover:text-amber-600 transition-colors"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? <ChevronUp className="w-4 h-4 text-amber-600" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </button>
                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 13. OFFICIAL FOOTER */}
      <footer className="bg-slate-950 text-slate-400 pt-16 pb-28 md:pb-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
            {/* Col 1: Brand & PT Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <img
                  src="https://daydreamsmassagejakarta.com/wp-content/uploads/2026/09/Logo-Daydreams-Jakarta-Massage-2.webp"
                  alt="Logo PT. DAYDREAMS MASSAGE SEHAT JAKARTA"
                  className="h-10 w-auto object-contain"
                />
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong>PT. DAYDREAMS MASSAGE SEHAT JAKARTA</strong>
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                Memberikan kenyamanan, privasi, dan relaksasi total bagi pelanggan tanpa harus keluar rumah. Menghadirkan terapis profesional bersertifikat langsung ke kamar hotel, apartemen mewah, dan hunian pribadi Anda di seluruh kawasan Jakarta.
              </p>
              <div className="text-[11px] text-amber-400 font-medium">
                100% Layanan Sehat, Sopan, & Menjaga Privasi
              </div>
            </div>

            {/* Col 2: Hubungi Admin 24 Jam */}
            <div>
              <h4 className="text-white font-semibold text-sm mb-4 pb-2 border-b border-slate-800">
                Admin Spa Online (24 Jam)
              </h4>
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <div className="text-pink-400 font-bold">Admin 1 (SISKA)</div>
                  <a
                    href={getAdminWaUrl('62895629139936', 'Halo Admin SISKA, saya ingin order terapis pijat.')}
                    target="_blank"
                    rel="noreferrer"
                    className="text-white hover:text-amber-400 block font-mono"
                  >
                    +62 895-6291-39936
                  </a>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <div className="text-amber-400 font-bold">Admin 2 (Mr.Erik)</div>
                  <a
                    href={getAdminWaUrl('6285217344735', 'Halo Admin Mr.Erik, saya ingin order terapis pijat.')}
                    target="_blank"
                    rel="noreferrer"
                    className="text-white hover:text-amber-400 block font-mono"
                  >
                    +62 852-1734-4735
                  </a>
                </div>
              </div>
            </div>

            {/* Col 3: Navigasi Cepat */}
            <div>
              <h4 className="text-white font-semibold text-sm mb-4 pb-2 border-b border-slate-800">
                Navigasi Cepat
              </h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#beranda" className="hover:text-amber-400 transition-colors">Beranda</a></li>
                <li><a href="#admin-section" className="hover:text-amber-400 transition-colors">Admin Spa 24 Jam</a></li>
                <li><a href="#layanan" className="hover:text-amber-400 transition-colors">Layanan Pijat & Gambar</a></li>
                <li><a href="#terapis" className="hover:text-amber-400 transition-colors">Terapis Standby (Pria & Wanita)</a></li>
                <li><a href="#area-layanan" className="hover:text-amber-400 transition-colors">Cakupan Area Jakarta</a></li>
                <li><a href="#tarif" className="hover:text-amber-400 transition-colors">Daftar Tarif & Paket</a></li>
                <li><a href="#tentang-kami" className="hover:text-amber-400 transition-colors">Tentang PT Daydreams</a></li>
                <li><a href="#booking" className="hover:text-amber-400 transition-colors">Formulir Booking WhatsApp</a></li>
              </ul>
            </div>

            {/* Col 4: Jam Operasional & Layanan */}
            <div>
              <h4 className="text-white font-semibold text-sm mb-4 pb-2 border-b border-slate-800">
                Jam Kerja & Area
              </h4>
              <div className="space-y-2.5 text-xs text-slate-300">
                <div>
                  <span className="text-slate-500 block">Operasional:</span>
                  <span className="font-semibold text-white">24 Jam Nonstop (Senin - Minggu)</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Jangkauan Cepat:</span>
                  <span>Jakarta Selatan, Pusat, Barat, Utara, Timur</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Target Lokasi:</span>
                  <span>Hotel Berbintang, Apartemen Mewah, & Rumah Tinggal</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-800 text-center text-xs text-slate-500 space-y-2">
            <p className="max-w-3xl mx-auto">
              <strong>Catatan Etika Layanan:</strong> Daydreams Massage Jakarta adalah layanan terapi kebugaran jasmani resmi & profesional di bawah naungan PT. DAYDREAMS MASSAGE SEHAT JAKARTA. Kami menolak dengan tegas segala bentuk permintaan di luar standar terapi kesehatan dan kesopanan.
            </p>
            <p>
              &copy; {new Date().getFullYear()} Daydreams Massage Jakarta • PT. DAYDREAMS MASSAGE SEHAT JAKARTA. Seluruh Hak Cipta Dilindungi.
            </p>
          </div>
        </div>
      </footer>

      {/* 14. FLOATING ACTION MODAL & BUTTONS */}
      {/* Floating WhatsApp Button for Desktop */}
      <div className="fixed bottom-6 right-6 z-40 hidden sm:block">
        <button
          onClick={() => setAdminModalOpen(true)}
          aria-label="Hubungi Admin WhatsApp Daydreams Massage"
          className="group relative flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-2xl transition-all duration-300 transform hover:scale-110"
        >
          <MessageCircle className="w-8 h-8" />
          <span className="absolute right-20 top-1/2 -translate-y-1/2 bg-slate-950 text-white text-xs font-semibold px-3 py-1.5 rounded-xl shadow-2xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none border border-slate-700">
            Chat Admin Online (24 Jam)
          </span>
        </button>
      </div>

      {/* Mobile Bottom Bar for Instant Booking */}
      <div className="fixed bottom-0 left-0 right-0 z-40 sm:hidden bg-slate-950/95 backdrop-blur-md border-t border-slate-800 p-2.5 px-4 shadow-2xl">
        <div className="flex items-center gap-2">
          <a
            href={getAdminWaUrl('62895629139936', 'Halo Admin SISKA, saya ingin order pijat panggilan sekarang.')}
            target="_blank"
            rel="noreferrer"
            className="flex-1 flex items-center justify-center py-2.5 px-3 rounded-xl bg-pink-900/60 border border-pink-700/60 text-white text-xs font-bold"
          >
            <MessageCircle className="w-3.5 h-3.5 mr-1 text-pink-300" />
            <span>SISKA</span>
          </a>

          <a
            href={getAdminWaUrl('6285217344735', 'Halo Admin Mr.Erik, saya ingin order pijat panggilan sekarang.')}
            target="_blank"
            rel="noreferrer"
            className="flex-1 flex items-center justify-center py-2.5 px-3 rounded-xl bg-amber-900/60 border border-amber-700/60 text-white text-xs font-bold"
          >
            <MessageCircle className="w-3.5 h-3.5 mr-1 text-amber-300" />
            <span>Mr.Erik</span>
          </a>

          <button
            onClick={() => setAdminModalOpen(true)}
            className="flex-1 flex items-center justify-center py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg"
          >
            <span>Pesan WA</span>
          </button>
        </div>
      </div>

      {/* 15. CHOOSE ADMIN POPUP MODAL */}
      {adminModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-md w-full text-white shadow-2xl space-y-5 relative">
            <button
              onClick={() => setAdminModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-left space-y-1">
              <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-950 px-2.5 py-0.5 rounded-full border border-amber-800">
                Layanan 24 Jam Nonstop
              </span>
              <h3 className="text-xl font-bold font-serif text-white pt-1">Admin Spa Online (24 Jam)</h3>
              <p className="text-xs text-slate-300">
                Silakan pilih admin untuk memesan atau konsultasi terapis yang ready:
              </p>
            </div>

            <div className="space-y-3 text-left">
              {/* Admin 1 (SISKA) */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 hover:border-pink-500 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-pink-500 to-rose-600 flex items-center justify-center text-white font-bold text-sm">
                      SK
                    </div>
                    <div>
                      <div className="font-bold text-sm text-white">Admin 1 (SISKA)</div>
                      <div className="text-xs text-amber-400 font-mono">+62 895-6291-39936</div>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
                    Online
                  </span>
                </div>
                <a
                  href={getAdminWaUrl('62895629139936', 'Halo Admin SISKA, saya ingin memesan / konsultasi terapis pijat panggilan yang ready.')}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => setAdminModalOpen(false)}
                  className="w-full flex items-center justify-center py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow transition-transform active:scale-95 mt-2"
                >
                  <MessageCircle className="w-4 h-4 mr-1.5" />
                  <span>Chat Admin SISKA via WhatsApp</span>
                </a>
              </div>

              {/* Admin 2 (Mr.Erik) */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 hover:border-amber-500 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 font-bold text-sm">
                      EK
                    </div>
                    <div>
                      <div className="font-bold text-sm text-white">Admin 2 (Mr.Erik)</div>
                      <div className="text-xs text-amber-400 font-mono">+62 852-1734-4735</div>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
                    Online
                  </span>
                </div>
                <a
                  href={getAdminWaUrl('6285217344735', 'Halo Admin Mr.Erik, saya ingin memesan / konsultasi terapis pijat panggilan yang ready.')}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => setAdminModalOpen(false)}
                  className="w-full flex items-center justify-center py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow transition-transform active:scale-95 mt-2"
                >
                  <MessageCircle className="w-4 h-4 mr-1.5" />
                  <span>Chat Admin Mr.Erik via WhatsApp</span>
                </a>
              </div>
            </div>

            <div className="pt-2 text-center">
              <p className="text-[11px] text-slate-400">
                PT. DAYDREAMS MASSAGE SEHAT JAKARTA • Fast Dispatch 30–45 Menit
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
