export interface ThemeFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export const THEME_FILES: ThemeFile[] = [
  {
    name: 'style.css',
    path: 'style.css',
    language: 'css',
    description: 'Header metadata tema WordPress resmi + deklarasi styling kustom dan animasi.',
    content: `/*
Theme Name: Daydreams Massage Jakarta
Theme URI: https://daydreamsmassagejakarta.com/
Author: Daydreams Studio
Author URI: https://daydreamsmassagejakarta.com/
Description: Tema WordPress SPA (Single Page Application) profesional, ultra-responsif, dan SEO-friendly untuk jasa Pijat Panggilan Jakarta 24 Jam. Dioptimalkan untuk konversi cepat ke WhatsApp, ramah perangkat mobile, dan dilengkapi schema structured data.
Version: 1.0.0
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: daydreams-massage
Tags: one-column, custom-menu, featured-images, translation-ready, full-width-template, landing-page
*/

/* Custom Smooth Scrolling & Typography Enhancements */
html {
  scroll-behavior: smooth;
  -webkit-tap-highlight-color: transparent;
}

body {
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  color: #1e293b;
  background-color: #f8fafc;
  overflow-x: hidden;
}

/* Elegant Brand Accents */
:root {
  --color-primary: #0f172a;       /* Deep Luxury Navy */
  --color-primary-light: #1e3a8a; /* Relaxing Ocean Blue */
  --color-accent: #d97706;        /* Warm Gold/Amber */
  --color-accent-light: #fef3c7;  /* Soft Warm Gold Wash */
  --color-accent-hover: #b45309;  /* Dark Gold */
  --color-wa: #25d366;            /* WhatsApp Green */
  --color-wa-hover: #1ebd56;
}

/* Subtle Relaxation Ambient Gradient */
.bg-spa-gradient {
  background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #172554 100%);
}

.bg-gold-gradient {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
}

.text-gold {
  color: #d97706;
}

.border-gold {
  border-color: #f59e0b;
}

/* Pulse animation for CTA & Floating WhatsApp */
@keyframes pulse-subtle {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 10px 25px -5px rgba(37, 211, 102, 0.4);
  }
  50% {
    transform: scale(1.05);
    box-shadow: 0 20px 30px -5px rgba(37, 211, 102, 0.6);
  }
}

.animate-pulse-wa {
  animation: pulse-subtle 2.8s infinite ease-in-out;
}

/* Floating Bar Mobile Offset */
@media (max-width: 768px) {
  body {
    padding-bottom: 72px; /* Prevent bottom navigation overlaying content */
  }
}

/* Hide scrollbar for category tabs */
.no-scrollbar::-webkit-scrollbar {
  display: none;
}
.no-scrollbar {
  -ms-overflow-style: none;
  scrollbar-width: none;
}`
  },
  {
    name: 'functions.php',
    path: 'functions.php',
    language: 'php',
    description: 'Registrasi menu, theme supports, enqueue Tailwind CDN & FontAwesome, customizer WhatsApp.',
    content: `<?php
/**
 * Daydreams Massage Jakarta - Functions and Definitions
 *
 * @package Daydreams_Massage_Jakarta
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function daydreams_massage_setup() {
    load_theme_textdomain('daydreams-massage', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    register_nav_menus(array(
        'primary' => __('Primary Menu (SPA Smooth Scroll)', 'daydreams-massage'),
        'footer'  => __('Footer Menu', 'daydreams-massage'),
    ));

    add_theme_support('html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
    ));
}
add_action('after_setup_theme', 'daydreams_massage_setup');

/**
 * Enqueue scripts and styles.
 */
function daydreams_massage_scripts() {
    wp_enqueue_style('daydreams-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap', array(), null);
    wp_enqueue_style('daydreams-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1');
    wp_enqueue_style('daydreams-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_script('daydreams-tailwindcss', 'https://cdn.tailwindcss.com', array(), '3.4.1', false);

    $tailwind_config = "
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        navy: { 800: '#172554', 900: '#0f172a', 950: '#090d16' },
                        gold: { 400: '#fbbf24', 500: '#f59e0b', 600: '#d97706', 700: '#b45309' },
                        wa: { light: '#25D366', dark: '#128C7E' }
                    },
                    fontFamily: {
                        sans: ['\"Plus Jakarta Sans\"', 'sans-serif'],
                        serif: ['\"Playfair Display\"', 'serif'],
                    }
                }
            }
        };
    ";
    wp_add_inline_script('daydreams-tailwindcss', $tailwind_config);
}
add_action('wp_enqueue_scripts', 'daydreams_massage_scripts');

/**
 * Theme Customizer Settings for WhatsApp, Phone, and Brand Info
 */
function daydreams_customize_register($wp_customize) {
    $wp_customize->add_section('daydreams_contact_section', array(
        'title'       => __('Pengaturan Kontak & WhatsApp', 'daydreams-massage'),
        'priority'    => 30,
        'description' => __('Konfigurasi nomor WhatsApp dan info operasional pijat panggilan.', 'daydreams-massage'),
    ));

    $wp_customize->add_setting('daydreams_whatsapp_number', array(
        'default'           => '6281234567890',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('daydreams_whatsapp_number', array(
        'label'       => __('Nomor WhatsApp (Tanpa + atau spasi, cth: 6281234567890)', 'daydreams-massage'),
        'section'     => 'daydreams_contact_section',
        'type'        => 'text',
    ));

    $wp_customize->add_setting('daydreams_phone_display', array(
        'default'           => '0812-3456-7890',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('daydreams_phone_display', array(
        'label'       => __('Nomor Telepon Tampilan', 'daydreams-massage'),
        'section'     => 'daydreams_contact_section',
        'type'        => 'text',
    ));

    $wp_customize->add_setting('daydreams_hours', array(
        'default'           => '24 Jam Nonstop (Senin - Minggu)',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('daydreams_hours', array(
        'label'       => __('Jam Operasional', 'daydreams-massage'),
        'section'     => 'daydreams_contact_section',
        'type'        => 'text',
    ));
}
add_action('customize_register', 'daydreams_customize_register');

function daydreams_get_wa_number() {
    $num = get_theme_mod('daydreams_whatsapp_number', '6281234567890');
    return preg_replace('/[^0-9]/', '', $num);
}

function daydreams_get_phone_display() {
    return get_theme_mod('daydreams_phone_display', '0812-3456-7890');
}

function daydreams_get_hours() {
    return get_theme_mod('daydreams_hours', '24 Jam Nonstop (Senin - Minggu)');
}

function daydreams_get_wa_link($custom_msg = '') {
    $wa_num = daydreams_get_wa_number();
    if (empty($custom_msg)) {
        $custom_msg = "Halo Admin Daydreams Massage Jakarta, saya ingin konsultasi / order layanan pijat panggilan 24 jam. Mohon info terapis yang ready.";
    }
    return 'https://api.whatsapp.com/send?phone=' . $wa_num . '&text=' . rawurlencode($custom_msg);
}`
  },
  {
    name: 'header.php',
    path: 'header.php',
    language: 'php',
    description: 'Tag head, SEO metadata, OpenGraph, JSON-LD LocalBusiness Schema, dan Fixed Navbar.',
    content: `<?php
/**
 * Header template for Daydreams Massage Jakarta theme
 *
 * @package Daydreams_Massage_Jakarta
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="scroll-smooth">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <!-- Primary SEO Meta Tags -->
    <meta name="title" content="Daydreams Massage Jakarta | Jasa Pijat Panggilan Jakarta 24 Jam">
    <meta name="description" content="Layanan Pijat Panggilan Jakarta 24 Jam ke Hotel, Apartemen, dan Rumah. Terapis pria & wanita profesional bersertifikat, ramah, sopan, dan terpercaya. Hubungi WhatsApp Daydreams Massage sekarang!">
    <meta name="keywords" content="pijat panggilan jakarta, massage panggilan jakarta 24 jam, pijat hotel jakarta, spa panggilan jakarta, refleksi jakarta, lulur panggilan jakarta, daydreams massage jakarta">
    <meta name="author" content="Daydreams Massage Jakarta">
    <meta name="robots" content="index, follow, max-image-preview:large">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="business.business">
    <meta property="og:url" content="https://daydreamsmassagejakarta.com/">
    <meta property="og:title" content="Daydreams Massage Jakarta - Pijat Panggilan 24 Jam Berpengalaman">
    <meta property="og:description" content="Layanan massage dan spa panggilan ke hotel, apartemen & rumah di seluruh area Jakarta Selatan, Pusat, Barat, Timur, Utara. Privasi terjamin!">
    <meta property="og:image" content="<?php echo esc_url(get_template_directory_uri() . '/screenshot.png'); ?>">
    <meta property="og:locale" content="id_ID">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Daydreams Massage Jakarta | Pijat Panggilan Jakarta 24 Jam">
    <meta name="twitter:description" content="Terapis profesional terpercaya datang ke lokasi Anda. Buka 24 Jam Nonstop di seluruh Jakarta.">

    <!-- Schema.org JSON-LD Structured Data for Local SEO -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "HealthAndBeautyBusiness",
      "name": "Daydreams Massage Jakarta",
      "image": "https://daydreamsmassagejakarta.com/assets/logo.png",
      "@id": "https://daydreamsmassagejakarta.com/#business",
      "url": "https://daydreamsmassagejakarta.com/",
      "telephone": "+<?php echo esc_js(daydreams_get_wa_number()); ?>",
      "priceRange": "Rp 200.000 - Rp 550.000",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Jakarta",
        "addressRegion": "DKI Jakarta",
        "addressCountry": "ID"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": -6.2088,
        "longitude": 106.8456
      },
      "openingHoursSpecification": {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
        "opens": "00:00",
        "closes": "23:59"
      },
      "areaServed": ["Jakarta Selatan","Jakarta Pusat","Jakarta Barat","Jakarta Timur","Jakarta Utara"],
      "sameAs": ["https://daydreamsmassagejakarta.com"]
    }
    </script>

    <?php wp_head(); ?>
</head>
<body <?php body_class('bg-slate-50 text-slate-800 antialiased selection:bg-gold-500 selection:text-white'); ?>>
<?php wp_body_open(); ?>

<!-- Top Announcement Banner -->
<div class="bg-navy-950 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
    <div class="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
        <div class="flex items-center space-x-2">
            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gold-500/20 text-gold-400 border border-gold-500/30">
                <i class="fa-solid fa-bolt mr-1"></i> Standby 24 Jam
            </span>
            <span class="hidden sm:inline">Layanan Cepat Datang ke Hotel, Apartemen & Rumah di Seluruh Jakarta</span>
            <span class="sm:hidden">Pijat Panggilan Hotel & Apartemen</span>
        </div>
        <div class="flex items-center space-x-4 text-slate-400">
            <a href="tel:<?php echo esc_attr(daydreams_get_wa_number()); ?>" class="hover:text-gold-400 transition-colors flex items-center">
                <i class="fa-solid fa-phone text-gold-500 mr-1.5"></i>
                <span><?php echo esc_html(daydreams_get_phone_display()); ?></span>
            </a>
            <span class="text-slate-600">|</span>
            <span class="text-emerald-400 flex items-center font-medium">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping mr-1.5 inline-block"></span> Terapis Ready
            </span>
        </div>
    </div>
</div>

<!-- Primary Fixed Navigation -->
<header id="main-header" class="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100 transition-all duration-300">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
            <a href="#beranda" class="group flex items-center space-x-3 text-decoration-none">
                <div class="w-11 h-11 rounded-xl bg-gradient-to-tr from-navy-900 via-navy-800 to-blue-900 flex items-center justify-center text-gold-400 shadow-md group-hover:scale-105 transition-transform duration-200">
                    <i class="fa-solid fa-spa text-xl"></i>
                </div>
                <div>
                    <span class="block text-xl font-bold font-serif tracking-tight text-navy-900 group-hover:text-gold-600 transition-colors">
                        Daydreams<span class="text-gold-600">.</span>
                    </span>
                    <span class="block text-[11px] font-medium tracking-wider uppercase text-slate-500">
                        Massage Jakarta 24 Jam
                    </span>
                </div>
            </a>

            <nav class="hidden lg:flex items-center space-x-8 text-sm font-medium text-slate-700" id="desktop-menu">
                <a href="#beranda" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Beranda</a>
                <a href="#layanan" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Layanan</a>
                <a href="#keunggulan" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Keunggulan</a>
                <a href="#area-layanan" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Area Jakarta</a>
                <a href="#tarif" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Tarif</a>
                <a href="#testimoni" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Testimoni</a>
                <a href="#booking" class="hover:text-gold-600 transition-colors py-2 border-b-2 border-transparent hover:border-gold-500">Cara Order</a>
            </nav>

            <div class="hidden sm:flex items-center space-x-3">
                <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams Massage, saya ingin booking terapis pijat panggilan sekarang.')); ?>" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   class="inline-flex items-center justify-center px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5">
                    <i class="fa-brands fa-whatsapp text-lg mr-2 text-white"></i>
                    <span>Pesan via WA</span>
                </a>
            </div>

            <div class="flex lg:hidden items-center space-x-2">
                <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin booking pijat panggilan.')); ?>" 
                   class="inline-flex sm:hidden items-center justify-center w-9 h-9 rounded-full bg-emerald-600 text-white text-sm">
                    <i class="fa-brands fa-whatsapp"></i>
                </a>
                <button type="button" 
                        id="mobile-menu-btn" 
                        aria-label="Toggle Navigasi Menu"
                        class="p-2.5 rounded-lg text-slate-700 hover:text-navy-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-gold-500 transition-colors">
                    <i class="fa-solid fa-bars text-xl" id="menu-icon-bars"></i>
                    <i class="fa-solid fa-xmark text-xl hidden" id="menu-icon-close"></i>
                </button>
            </div>
        </div>
    </div>

    <div id="mobile-menu-drawer" class="hidden lg:hidden bg-white border-b border-slate-200 shadow-xl px-4 pt-3 pb-6 space-y-2">
        <a href="#beranda" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Beranda</a>
        <a href="#layanan" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Daftar Layanan Pijat</a>
        <a href="#keunggulan" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Keunggulan Kami</a>
        <a href="#area-layanan" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Jangkauan Area Jakarta</a>
        <a href="#tarif" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Daftar Harga & Paket</a>
        <a href="#testimoni" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Testimoni Pelanggan</a>
        <a href="#booking" class="mobile-nav-link block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:text-gold-600 hover:bg-slate-50">Formulir Booking Cepat</a>
        
        <div class="pt-4 border-t border-slate-100 flex flex-col gap-2">
            <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Daydreams Massage Jakarta, saya butuh terapis panggilan ke hotel/apartemen/rumah sekarang.')); ?>"
               target="_blank"
               rel="noopener noreferrer" 
               class="w-full flex items-center justify-center py-3 px-4 rounded-xl bg-emerald-600 text-white font-semibold shadow text-sm">
                <i class="fa-brands fa-whatsapp text-lg mr-2"></i> Chat WhatsApp Admin (Fast Response)
            </a>
            <a href="tel:<?php echo esc_attr(daydreams_get_wa_number()); ?>"
               class="w-full flex items-center justify-center py-2.5 px-4 rounded-xl bg-slate-100 text-slate-700 font-medium text-sm">
                <i class="fa-solid fa-phone mr-2 text-gold-600"></i> Telepon: <?php echo esc_html(daydreams_get_phone_display()); ?>
            </a>
        </div>
    </div>
</header>`
  },
  {
    name: 'footer.php',
    path: 'footer.php',
    language: 'php',
    description: 'Footer info, floating WhatsApp button, mobile bottom bar, dan JavaScript handlers.',
    content: `<?php
/**
 * Footer template for Daydreams Massage Jakarta theme
 *
 * @package Daydreams_Massage_Jakarta
 */
?>

<footer class="bg-navy-950 text-slate-400 pt-16 pb-24 md:pb-16 border-t border-slate-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
            <div>
                <div class="flex items-center space-x-3 mb-5">
                    <div class="w-10 h-10 rounded-xl bg-gold-600 flex items-center justify-center text-navy-950 font-bold text-lg shadow">
                        <i class="fa-solid fa-spa"></i>
                    </div>
                    <span class="text-xl font-bold font-serif text-white tracking-tight">
                        Daydreams<span class="text-gold-400">.</span>
                    </span>
                </div>
                <p class="text-sm text-slate-300 leading-relaxed mb-6">
                    Penyedia jasa pijat panggilan Jakarta 24 jam profesional, terpercaya, dan berorientasi pada kenyamanan Anda. Menjangkau hotel berbintang, apartemen, dan rumah tinggal dengan terapis pria dan wanita bersertifikat.
                </p>
                <div class="flex items-center space-x-3 text-gold-400 text-sm">
                    <i class="fa-solid fa-shield-halved text-lg"></i>
                    <span class="text-slate-300 text-xs font-medium">100% Layanan Sehat, Sopan, & Menjaga Privasi</span>
                </div>
            </div>

            <div>
                <h4 class="text-white font-semibold text-base mb-5 pb-2 border-b border-slate-800 flex items-center">
                    <span class="w-2 h-2 rounded-full bg-gold-500 mr-2"></span> Navigasi Halaman
                </h4>
                <ul class="space-y-2.5 text-sm">
                    <li><a href="#beranda" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Beranda</a></li>
                    <li><a href="#layanan" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Menu Layanan Pijat</a></li>
                    <li><a href="#keunggulan" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Keunggulan Terapis</a></li>
                    <li><a href="#area-layanan" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Area Jangkauan Jakarta</a></li>
                    <li><a href="#tarif" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Paket & Tarif Harga</a></li>
                    <li><a href="#testimoni" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Ulasan / Testimoni</a></li>
                    <li><a href="#booking" class="hover:text-gold-400 transition-colors flex items-center"><i class="fa-solid fa-chevron-right text-[10px] mr-2 text-slate-600"></i> Form Booking Online</a></li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-semibold text-base mb-5 pb-2 border-b border-slate-800 flex items-center">
                    <span class="w-2 h-2 rounded-full bg-gold-500 mr-2"></span> Menu Pijat Terfavorit
                </h4>
                <ul class="space-y-2 text-sm">
                    <li class="flex items-center justify-between text-slate-300">
                        <span>Traditional Body Massage</span>
                        <span class="text-xs bg-slate-800 px-2 py-0.5 rounded text-gold-400">90 - 120 Menit</span>
                    </li>
                    <li class="flex items-center justify-between text-slate-300">
                        <span>Reflexology & Pijat Capek</span>
                        <span class="text-xs bg-slate-800 px-2 py-0.5 rounded text-gold-400">60 - 90 Menit</span>
                    </li>
                    <li class="flex items-center justify-between text-slate-300">
                        <span>Pijat Full Body + Kerokan</span>
                        <span class="text-xs bg-slate-800 px-2 py-0.5 rounded text-gold-400">90 - 120 Menit</span>
                    </li>
                    <li class="flex items-center justify-between text-slate-300">
                        <span>Body Scrub & Lulur Herbal</span>
                        <span class="text-xs bg-slate-800 px-2 py-0.5 rounded text-gold-400">120 Menit</span>
                    </li>
                    <li class="flex items-center justify-between text-slate-300">
                        <span>Couple Massage Suite</span>
                        <span class="text-xs bg-slate-800 px-2 py-0.5 rounded text-gold-400">120 Menit</span>
                    </li>
                </ul>
            </div>

            <div>
                <h4 class="text-white font-semibold text-base mb-5 pb-2 border-b border-slate-800 flex items-center">
                    <span class="w-2 h-2 rounded-full bg-gold-500 mr-2"></span> Kontak & Operasional
                </h4>
                <div class="space-y-3 text-sm">
                    <div class="flex items-start space-x-3">
                        <i class="fa-solid fa-clock text-gold-500 mt-1"></i>
                        <div>
                            <span class="block text-white font-medium">Jam Operasional:</span>
                            <span class="text-slate-300"><?php echo esc_html(daydreams_get_hours()); ?></span>
                        </div>
                    </div>
                    <div class="flex items-start space-x-3">
                        <i class="fa-brands fa-whatsapp text-emerald-400 text-lg mt-0.5"></i>
                        <div>
                            <span class="block text-white font-medium">WhatsApp Booking:</span>
                            <a href="<?php echo esc_url(daydreams_get_wa_link()); ?>" class="text-emerald-400 hover:underline">
                                +<?php echo esc_html(daydreams_get_wa_number()); ?>
                            </a>
                        </div>
                    </div>
                    <div class="flex items-start space-x-3">
                        <i class="fa-solid fa-location-dot text-gold-500 mt-1"></i>
                        <div>
                            <span class="block text-white font-medium">Area Layanan:</span>
                            <span class="text-slate-300">Seluruh Jakarta Selatan, Pusat, Barat, Timur, dan Utara.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="pt-8 mt-8 border-t border-slate-800/80 text-center text-xs text-slate-400 space-y-3">
            <p class="max-w-3xl mx-auto leading-relaxed">
                <strong>Catatan Etika Layanan:</strong> Daydreams Massage Jakarta adalah penyedia layanan terapi kebugaran jasmani resmi & profesional. Kami menolak segala bentuk permintaan di luar standar terapi kesehatan dan kesopanan.
            </p>
            <p>
                &copy; <?php echo date('Y'); ?> <a href="https://daydreamsmassagejakarta.com/" class="text-white hover:text-gold-400 font-medium">Daydreams Massage Jakarta</a>. Seluruh Hak Cipta Dilindungi Undang-Undang.
            </p>
        </div>
    </div>
</footer>

<!-- Floating WhatsApp Button (Desktop & Tablet) -->
<div class="fixed bottom-6 right-6 z-50 hidden sm:block">
    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams Massage, saya ingin pesan terapis pijat panggilan sekarang.')); ?>"
       target="_blank"
       rel="noopener noreferrer"
       aria-label="Hubungi WhatsApp Daydreams Massage"
       class="group relative flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-2xl transition-all duration-300 transform hover:scale-110 animate-pulse-wa">
        <i class="fa-brands fa-whatsapp text-3xl"></i>
        <span class="absolute right-20 top-1/2 -translate-y-1/2 bg-navy-950 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none border border-slate-700">
            Chat WhatsApp 24 Jam
        </span>
    </a>
</div>

<!-- Mobile Bottom Floating Action Bar -->
<div class="fixed bottom-0 left-0 right-0 z-50 sm:hidden bg-navy-950/95 backdrop-blur-md border-t border-slate-800 p-2.5 px-4 shadow-[0_-4px_20px_rgba(0,0,0,0.3)]">
    <div class="flex items-center gap-3">
        <a href="tel:<?php echo esc_attr(daydreams_get_wa_number()); ?>" 
           class="flex-1 flex items-center justify-center py-2.5 px-3 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-medium transition-colors border border-slate-700">
            <i class="fa-solid fa-phone text-gold-400 mr-1.5 text-sm"></i> Telepon
        </a>
        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams Massage, saya ingin order pijat panggilan langsung ke lokasi saya.')); ?>" 
           target="_blank"
           rel="noopener noreferrer"
           class="flex-[2] flex items-center justify-center py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-lg transition-transform active:scale-95">
            <i class="fa-brands fa-whatsapp text-base mr-1.5 text-white"></i> Booking via WA (24 Jam)
        </a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuBtn = document.getElementById('mobile-menu-btn');
    const menuDrawer = document.getElementById('mobile-menu-drawer');
    const iconBars = document.getElementById('menu-icon-bars');
    const iconClose = document.getElementById('menu-icon-close');
    const mobileLinks = document.querySelectorAll('.mobile-nav-link');

    if (menuBtn && menuDrawer) {
        menuBtn.addEventListener('click', function() {
            const isHidden = menuDrawer.classList.contains('hidden');
            if (isHidden) {
                menuDrawer.classList.remove('hidden');
                iconBars.classList.add('hidden');
                iconClose.classList.remove('hidden');
            } else {
                menuDrawer.classList.add('hidden');
                iconBars.classList.remove('hidden');
                iconClose.classList.add('hidden');
            }
        });

        mobileLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                menuDrawer.classList.add('hidden');
                iconBars.classList.remove('hidden');
                iconClose.classList.add('hidden');
            });
        });
    }

    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId && targetId !== '#') {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    e.preventDefault();
                    const headerHeight = document.getElementById('main-header')?.offsetHeight || 70;
                    const elementPosition = targetElement.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerHeight;

                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    const bookingForm = document.getElementById('quick-booking-form');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const nama = document.getElementById('bf-nama')?.value.trim() || '-';
            const layanan = document.getElementById('bf-layanan')?.value || 'Traditional Body Massage';
            const durasi = document.getElementById('bf-durasi')?.value || '90 Menit';
            const gender = document.getElementById('bf-gender')?.value || 'Terapis Wanita';
            const area = document.getElementById('bf-area')?.value || 'Jakarta Selatan';
            const alamat = document.getElementById('bf-alamat')?.value.trim() || '-';
            const waktu = document.getElementById('bf-waktu')?.value || 'Sekarang (Secepatnya)';

            const text = \`*FORMULIR ORDER PIJAT PANGGILAN - DAYDREAMS MASSAGE*\\n\` +
                         \`━━━━━━━━━━━━━━━━━━━━\\n\` +
                         \`👤 *Nama:* \${nama}\\n\` +
                         \`💆‍♂️ *Layanan:* \${layanan}\\n\` +
                         \`⏱️ *Durasi:* \${durasi}\\n\` +
                         \`👥 *Pilihan Terapis:* \${gender}\\n\` +
                         \`📍 *Wilayah:* \${area}\\n\` +
                         \`🏢 *Lokasi/Alamat/No Kamar:* \${alamat}\\n\` +
                         \`🕒 *Waktu Panggilan:* \${waktu}\\n\` +
                         \`━━━━━━━━━━━━━━━━━━━━\\n\` +
                         \`Mohon info ketersediaan terapis & total biayanya. Terima kasih!\`;

            const adminPhone = "<?php echo esc_js(daydreams_get_wa_number()); ?>";
            const waUrl = \`https://api.whatsapp.com/send?phone=\${adminPhone}&text=\${encodeURIComponent(text)}\`;
            window.open(waUrl, '_blank');
        });
    }
});
</script>

<?php wp_footer(); ?>
</body>
</html>`
  },
  {
    name: 'front-page.php',
    path: 'front-page.php',
    language: 'php',
    description: 'Template utama SPA: Hero, Keunggulan, 6 Menu Layanan, Area Coverage Jakarta, Tabel Harga, Testimoni, Booking WA.',
    content: `<?php
/**
 * Template Name: Front Page SPA Landing Page
 * Description: Single Page Application Landing Page for Daydreams Massage Jakarta
 *
 * @package Daydreams_Massage_Jakarta
 */

get_header();
?>

<main id="primary" class="site-main">
    <!-- HERO SECTION -->
    <section id="beranda" class="relative overflow-hidden bg-gradient-to-b from-navy-950 via-navy-900 to-slate-900 text-white pt-12 pb-20 md:pt-20 md:pb-28">
        <div class="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute bottom-0 left-10 w-80 h-80 bg-gold-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                <div class="lg:col-span-7 text-center lg:text-left space-y-6">
                    <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-800/80 border border-gold-500/30 text-xs font-semibold tracking-wide text-gold-400">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block"></span>
                        <span>TERAPIS STANDBY 24 JAM JAKARTA</span>
                    </div>

                    <h1 class="text-3xl sm:text-5xl lg:text-6xl font-bold font-serif tracking-tight leading-tight sm:leading-none text-white">
                        Pijat Panggilan Jakarta <br class="hidden sm:inline">
                        <span class="text-transparent bg-clip-text bg-gradient-to-r from-gold-400 via-amber-300 to-gold-500">
                            24 Jam Profesional
                        </span>
                    </h1>

                    <p class="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                        Layanan massage & spa panggilan resmi langsung ke <strong class="text-white">Hotel, Apartemen, dan Rumah</strong> di seluruh wilayah Jakarta. Rasakan sensasi relaksasi mendalam dari terapis berpengalaman, ramah, sopan, dan menjaga privasi Anda 100%.
                    </p>

                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-left">
                        <div class="bg-slate-800/60 backdrop-blur-sm p-3 rounded-xl border border-slate-700/60">
                            <div class="flex items-center space-x-2 text-gold-400 mb-1">
                                <i class="fa-solid fa-certificate text-sm"></i>
                                <span class="text-xs font-bold text-white">Terapis Ahli</span>
                            </div>
                            <p class="text-[11px] text-slate-400">Pria & Wanita bersertifikat</p>
                        </div>
                        <div class="bg-slate-800/60 backdrop-blur-sm p-3 rounded-xl border border-slate-700/60">
                            <div class="flex items-center space-x-2 text-emerald-400 mb-1">
                                <i class="fa-solid fa-clock text-sm"></i>
                                <span class="text-xs font-bold text-white">Respon Cepat</span>
                            </div>
                            <p class="text-[11px] text-slate-400">30-45 menit tiba di lokasi</p>
                        </div>
                        <div class="col-span-2 sm:col-span-1 bg-slate-800/60 backdrop-blur-sm p-3 rounded-xl border border-slate-700/60">
                            <div class="flex items-center space-x-2 text-blue-400 mb-1">
                                <i class="fa-solid fa-shield-halved text-sm"></i>
                                <span class="text-xs font-bold text-white">100% Amanah</span>
                            </div>
                            <p class="text-[11px] text-slate-400">Etika & privasi terjaga</p>
                        </div>
                    </div>

                    <div class="pt-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams Massage, saya ingin panggil terapis pijat ke lokasi saya sekarang.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 rounded-full text-base font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xl hover:shadow-emerald-600/30 transition-all duration-200 transform hover:-translate-y-1">
                            <i class="fa-brands fa-whatsapp text-2xl mr-3 text-white"></i>
                            <span>Panggil Terapis via WhatsApp</span>
                        </a>
                        <a href="#layanan"
                           class="w-full sm:w-auto inline-flex items-center justify-center px-7 py-4 rounded-full text-base font-semibold text-slate-200 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 transition-all">
                            <i class="fa-solid fa-list-check mr-2 text-gold-400"></i>
                            <span>Lihat Menu & Harga</span>
                        </a>
                    </div>

                    <div class="pt-3 flex items-center justify-center lg:justify-start space-x-3 text-xs text-slate-400">
                        <div class="flex text-amber-400">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <span class="text-slate-200 font-semibold">4.9 / 5.0</span>
                        <span>(1.850+ Tamu Hotel & Warga Jakarta Puas)</span>
                    </div>
                </div>

                <div class="lg:col-span-5">
                    <div class="bg-gradient-to-b from-slate-800/90 to-navy-950/90 rounded-3xl p-6 sm:p-8 border border-slate-700 shadow-2xl backdrop-blur-md relative">
                        <div class="absolute -top-3.5 right-6 bg-gradient-to-r from-gold-500 to-amber-600 text-white text-[11px] font-bold px-3.5 py-1 rounded-full shadow-md uppercase tracking-wider">
                            Paling Populer
                        </div>

                        <div class="flex items-center space-x-3 mb-6">
                            <div class="w-12 h-12 rounded-2xl bg-gold-500/20 border border-gold-500/30 flex items-center justify-center text-gold-400 text-xl">
                                <i class="fa-solid fa-spa"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-white font-serif">Pijat Tradisional Relaksasi</h3>
                                <p class="text-xs text-slate-400">Cocok untuk capek kerja, pegal, atau badan kaku</p>
                            </div>
                        </div>

                        <div class="space-y-3 mb-6 text-sm">
                            <div class="flex items-center justify-between py-2 border-b border-slate-700/60 text-slate-300">
                                <span class="flex items-center"><i class="fa-solid fa-check text-emerald-400 text-xs mr-2"></i> Pilihan Durasi</span>
                                <span class="font-semibold text-white">90 Menit / 120 Menit</span>
                            </div>
                            <div class="flex items-center justify-between py-2 border-b border-slate-700/60 text-slate-300">
                                <span class="flex items-center"><i class="fa-solid fa-check text-emerald-400 text-xs mr-2"></i> Pilihan Terapis</span>
                                <span class="font-semibold text-white">Pria / Wanita Profesional</span>
                            </div>
                            <div class="flex items-center justify-between py-2 border-b border-slate-700/60 text-slate-300">
                                <span class="flex items-center"><i class="fa-solid fa-check text-emerald-400 text-xs mr-2"></i> Perlengkapan</span>
                                <span class="font-semibold text-white">Minyak Aromaterapi & Krim</span>
                            </div>
                            <div class="flex items-center justify-between py-2 border-b border-slate-700/60 text-slate-300">
                                <span class="flex items-center"><i class="fa-solid fa-check text-emerald-400 text-xs mr-2"></i> Tarif Mulai Dari</span>
                                <span class="font-bold text-gold-400 text-base">Rp 200.000,-</span>
                            </div>
                        </div>

                        <div class="bg-navy-950 p-4 rounded-2xl border border-slate-700 text-center space-y-3">
                            <p class="text-xs text-slate-400">
                                Butuh terapis datang ke kamar hotel / apartemen Anda dalam 30-45 menit?
                            </p>
                            <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams Massage, saya ingin order Paket Pijat Tradisional Relaksasi 90 menit. Tolong info ketersediaan terapis.')); ?>"
                               target="_blank"
                               rel="noopener noreferrer"
                               class="w-full flex items-center justify-center py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md transition-transform active:scale-95">
                                <i class="fa-brands fa-whatsapp mr-2 text-lg"></i> Klik Untuk Pesan Sekarang
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION KEUNGGULAN -->
    <section id="keunggulan" class="py-16 md:py-24 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-16 space-y-3">
                <span class="text-xs font-bold uppercase tracking-widest text-gold-600 bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                    Standar Kualitas Tertinggi
                </span>
                <h2 class="text-3xl sm:text-4xl font-bold font-serif text-navy-900">
                    Mengapa Daydreams Massage Menjadi Pilihan Utama di Jakarta?
                </h2>
                <p class="text-slate-600 text-sm sm:text-base leading-relaxed">
                    Kami menghadirkan pengalaman spa hotel berbintang langsung ke ruang privat Anda dengan dedikasi pada kebersihan, profesionalisme, dan kesopanan.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-gold-400 hover:shadow-lg transition-all duration-300 group">
                    <div class="w-14 h-14 rounded-2xl bg-navy-900 text-gold-400 flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform">
                        <i class="fa-solid fa-id-card-clip"></i>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Terapis Bersertifikat & Berpengalaman</h3>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Terapis kami telah melalui seleksi ketat dan pelatihan profesional. Menguasai titik saraf, teknik pijat anatomi tubuh, serta ramah dan mengutamakan kenyamanan pelanggan.
                    </p>
                </div>

                <div class="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-gold-400 hover:shadow-lg transition-all duration-300 group">
                    <div class="w-14 h-14 rounded-2xl bg-navy-900 text-emerald-400 flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Layanan Standby 24 Jam Nonstop</h3>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Lelah setelah penerbangan malam, lembur kantor, atau butuh relaksasi dini hari? Terapis Daydreams Massage siap meluncur kapan pun Anda membutuhkan, 24/7.
                    </p>
                </div>

                <div class="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-gold-400 hover:shadow-lg transition-all duration-300 group">
                    <div class="w-14 h-14 rounded-2xl bg-navy-900 text-gold-400 flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform">
                        <i class="fa-solid fa-user-shield"></i>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Privasi & Keamanan Terjamin 100%</h3>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Layanan kebugaran resmi dengan integritas tinggi. Data lokasi, nomor kontak, serta privasi tempat tinggal atau kamar hotel Anda kami jaga secara rahasia dan aman.
                    </p>
                </div>

                <div class="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-gold-400 hover:shadow-lg transition-all duration-300 group">
                    <div class="w-14 h-14 rounded-2xl bg-navy-900 text-blue-400 flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform">
                        <i class="fa-solid fa-venus-mars"></i>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Pilihan Terapis Pria / Wanita</h3>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Anda bebas menentukan preferensi terapis pria atau wanita sesuai dengan rasa nyaman dan kebutuhan terapi tubuh Anda.
                    </p>
                </div>

                <div class="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-gold-400 hover:shadow-lg transition-all duration-300 group">
                    <div class="w-14 h-14 rounded-2xl bg-navy-900 text-gold-400 flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform">
                        <i class="fa-solid fa-bottle-droplet"></i>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Minyak Aromaterapi Alami</h3>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Menggunakan essential oil berkualitas tinggi yang harum menenangkan, tidak lengket di kulit, serta membantu meredakan stres dan ketegangan otot.
                    </p>
                </div>

                <div class="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-gold-400 hover:shadow-lg transition-all duration-300 group">
                    <div class="w-14 h-14 rounded-2xl bg-navy-900 text-purple-400 flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform">
                        <i class="fa-solid fa-map-location-dot"></i>
                    </div>
                    <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Jangkauan Seluruh DKI Jakarta</h3>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Terapis tersebar di berbagai titik strategis Jakarta Selatan, Pusat, Barat, Timur, dan Utara. Waktu tunggu lebih singkat (estimasi 30 - 45 menit).
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION LAYANAN & TARIF -->
    <section id="layanan" class="py-16 md:py-24 bg-slate-100/70 border-y border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-16 space-y-3">
                <span class="text-xs font-bold uppercase tracking-widest text-gold-600 bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                    Menu & Tarif Transparan
                </span>
                <h2 class="text-3xl sm:text-4xl font-bold font-serif text-navy-900">
                    Layanan Pijat Panggilan Daydreams
                </h2>
                <p class="text-slate-600 text-sm sm:text-base leading-relaxed">
                    Pilih paket pijat sesuai dengan keluhan tubuh Anda. Tarif transparan tanpa biaya tersembunyi.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Card 1 -->
                <div class="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
                    <div class="absolute top-5 right-5 bg-gold-100 text-gold-700 text-[11px] font-bold px-3 py-1 rounded-full uppercase">
                        Best Seller
                    </div>
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center text-xl mb-4">
                            <i class="fa-solid fa-hands"></i>
                        </div>
                        <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Traditional Body Massage</h3>
                        <p class="text-slate-600 text-xs sm:text-sm mb-4 leading-relaxed">
                            Teknik pemijatan tradisional Nusantara menggunakan telapak tangan dan ibu jari. Sangat efektif meredakan otot tegang, pegal punggung, dan melancarkan sirkulasi darah.
                        </p>
                        <ul class="space-y-2 mb-6 text-xs text-slate-600">
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Pijat seluruh tubuh (kaki, punggung, leher, kepala)</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Free minyak aromaterapi relaksasi</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Durasi 90 atau 120 Menit</li>
                        </ul>
                    </div>
                    <div class="pt-4 border-t border-slate-100">
                        <div class="flex items-baseline justify-between mb-4">
                            <span class="text-xs text-slate-500">Mulai dari</span>
                            <div>
                                <span class="text-xl font-bold text-navy-900">Rp 200.000</span>
                                <span class="text-xs text-slate-500">/ 90 mnt</span>
                            </div>
                        </div>
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin memesan Traditional Body Massage (90 Menit). Mohon infokan ketersediaan terapis.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl bg-navy-900 hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
                            <i class="fa-brands fa-whatsapp mr-2 text-sm"></i> Pesan Layanan Ini
                        </a>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center text-xl mb-4">
                            <i class="fa-solid fa-shoe-prints"></i>
                        </div>
                        <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Reflexology & Totok Wajah</h3>
                        <p class="text-slate-600 text-xs sm:text-sm mb-4 leading-relaxed">
                            Penekanan pada titik akupresur telapak kaki dan tangan untuk menstimulasi organ vital tubuh, dikombinasikan dengan totok wajah agar sirkulasi wajah segar dan bercahaya.
                        </p>
                        <ul class="space-y-2 mb-6 text-xs text-slate-600">
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Fokus titik refleksi kaki & telapak tangan</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Totok wajah relaksasi anti-stres</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Durasi 60 atau 90 Menit</li>
                        </ul>
                    </div>
                    <div class="pt-4 border-t border-slate-100">
                        <div class="flex items-baseline justify-between mb-4">
                            <span class="text-xs text-slate-500">Mulai dari</span>
                            <div>
                                <span class="text-xl font-bold text-navy-900">Rp 175.000</span>
                                <span class="text-xs text-slate-500">/ 60 mnt</span>
                            </div>
                        </div>
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin pesan layanan Reflexology & Totok Wajah. Mohon infokan jadwal terapis ready.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl bg-navy-900 hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
                            <i class="fa-brands fa-whatsapp mr-2 text-sm"></i> Pesan Layanan Ini
                        </a>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
                    <div class="absolute top-5 right-5 bg-emerald-100 text-emerald-800 text-[11px] font-bold px-3 py-1 rounded-full uppercase">
                        Favorit Masuk Angin
                    </div>
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center text-xl mb-4">
                            <i class="fa-solid fa-fire"></i>
                        </div>
                        <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Pijat Tubuh + Kerokan</h3>
                        <p class="text-slate-600 text-xs sm:text-sm mb-4 leading-relaxed">
                            Solusi ampuh untuk badan demam ringan, masuk angin, kembung, dan pegal linu setelah perjalanan jauh. Dikombinasikan dengan minyak hangat aromatik.
                        </p>
                        <ul class="space-y-2 mb-6 text-xs text-slate-600">
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Pijatan relaksasi + teknik kerokan higienis</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Minyak kayu putih / minyak jahe hangat</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Durasi 90 atau 120 Menit</li>
                        </ul>
                    </div>
                    <div class="pt-4 border-t border-slate-100">
                        <div class="flex items-baseline justify-between mb-4">
                            <span class="text-xs text-slate-500">Mulai dari</span>
                            <div>
                                <span class="text-xl font-bold text-navy-900">Rp 225.000</span>
                                <span class="text-xs text-slate-500">/ 90 mnt</span>
                            </div>
                        </div>
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya butuh Pijat Full Body + Kerokan karena badan meriang/masuk angin. Mohon terapis segera datang.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl bg-navy-900 hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
                            <i class="fa-brands fa-whatsapp mr-2 text-sm"></i> Pesan Layanan Ini
                        </a>
                    </div>
                </div>

                <!-- Card 4 -->
                <div class="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center text-xl mb-4">
                            <i class="fa-solid fa-leaf"></i>
                        </div>
                        <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Lulur Tradisional & Scrub</h3>
                        <p class="text-slate-600 text-xs sm:text-sm mb-4 leading-relaxed">
                            Kombinasi pijat relaksasi tubuh dengan pembersihan kulit memakai butiran scrub lulur herbal alami. Mengangkat sel kulit mati dan menghaluskan permukaan kulit.
                        </p>
                        <ul class="space-y-2 mb-6 text-xs text-slate-600">
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Pijat relaksasi 60 mnt + Lulur 60 mnt</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Bahan alami (bengkoang, zaitun, atau kopi)</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Kulit wangi, cerah, & bersih</li>
                        </ul>
                    </div>
                    <div class="pt-4 border-t border-slate-100">
                        <div class="flex items-baseline justify-between mb-4">
                            <span class="text-xs text-slate-500">Mulai dari</span>
                            <div>
                                <span class="text-xl font-bold text-navy-900">Rp 275.000</span>
                                <span class="text-xs text-slate-500">/ 120 mnt</span>
                            </div>
                        </div>
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin memesan layanan Lulur Tradisional & Scrub Herbal 120 menit.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl bg-navy-900 hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
                            <i class="fa-brands fa-whatsapp mr-2 text-sm"></i> Pesan Layanan Ini
                        </a>
                    </div>
                </div>

                <!-- Card 5 -->
                <div class="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center text-xl mb-4">
                            <i class="fa-solid fa-dumbbell"></i>
                        </div>
                        <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Deep Tissue / Pijat Otot</h3>
                        <p class="text-slate-600 text-xs sm:text-sm mb-4 leading-relaxed">
                            Dirancang khusus untuk atlet, penggemar gym, atau Anda yang mengalami kekakuan otot kronis pada pinggang, bahu, dan betis akibat rutinitas padat di Jakarta.
                        </p>
                        <ul class="space-y-2 mb-6 text-xs text-slate-600">
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Tekanan lebih bertenaga & tepat sasaran</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Mengurai simpul otot (muscle knot)</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Durasi 90 atau 120 Menit</li>
                        </ul>
                    </div>
                    <div class="pt-4 border-t border-slate-100">
                        <div class="flex items-baseline justify-between mb-4">
                            <span class="text-xs text-slate-500">Mulai dari</span>
                            <div>
                                <span class="text-xl font-bold text-navy-900">Rp 250.000</span>
                                <span class="text-xs text-slate-500">/ 90 mnt</span>
                            </div>
                        </div>
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin booking Deep Tissue Massage / Pijat Otot Bertenaga.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl bg-navy-900 hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
                            <i class="fa-brands fa-whatsapp mr-2 text-sm"></i> Pesan Layanan Ini
                        </a>
                    </div>
                </div>

                <!-- Card 6 -->
                <div class="bg-white rounded-3xl p-7 border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
                    <div class="absolute top-5 right-5 bg-indigo-100 text-indigo-800 text-[11px] font-bold px-3 py-1 rounded-full uppercase">
                        Paket Pasangan
                    </div>
                    <div>
                        <div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center text-xl mb-4">
                            <i class="fa-solid fa-heart"></i>
                        </div>
                        <h3 class="text-xl font-bold text-navy-900 mb-2 font-serif">Couple Massage Package</h3>
                        <p class="text-slate-600 text-xs sm:text-sm mb-4 leading-relaxed">
                            Layanan pijat berdua sekaligus untuk pasangan suami istri di kamar hotel atau rumah. Kami kirim 2 orang terapis profesional secara bersamaan.
                        </p>
                        <ul class="space-y-2 mb-6 text-xs text-slate-600">
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> 2 Terapis profesional hadir sekaligus</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Full Body Massage + Totok Wajah/Refleksi</li>
                            <li class="flex items-center"><i class="fa-solid fa-circle-check text-emerald-500 mr-2"></i> Durasi 120 Menit</li>
                        </ul>
                    </div>
                    <div class="pt-4 border-t border-slate-100">
                        <div class="flex items-baseline justify-between mb-4">
                            <span class="text-xs text-slate-500">Mulai dari</span>
                            <div>
                                <span class="text-xl font-bold text-navy-900">Rp 450.000</span>
                                <span class="text-xs text-slate-500">/ 2 Orang</span>
                            </div>
                        </div>
                        <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams Massage, saya ingin booking Paket Couple Massage untuk 2 orang terapis bersamaan.')); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="w-full inline-flex items-center justify-center py-2.5 px-4 rounded-xl bg-navy-900 hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
                            <i class="fa-brands fa-whatsapp mr-2 text-sm"></i> Pesan Layanan Ini
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION AREA LAYANAN (JAKARTA COVERAGE) -->
    <section id="area-layanan" class="py-16 md:py-24 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                <div class="lg:col-span-6 space-y-6">
                    <span class="text-xs font-bold uppercase tracking-widest text-gold-600 bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                        Jangkauan Layanan Luas
                    </span>
                    <h2 class="text-3xl sm:text-4xl font-bold font-serif text-navy-900">
                        Siap Datang ke Seluruh Wilayah DKI Jakarta 24 Jam
                    </h2>
                    <p class="text-slate-600 text-sm sm:text-base leading-relaxed">
                        Kami memiliki jaringan terapis yang berdomisili di berbagai penjuru ibukota. Di mana pun lokasi hotel bintang 3/4/5, apartemen mewah, residence, atau rumah tinggal Anda, tim Daydreams Massage siap meluncur cepat.
                    </p>

                    <div class="space-y-3">
                        <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                            <div class="flex items-center justify-between font-bold text-navy-900 text-sm">
                                <span class="flex items-center"><i class="fa-solid fa-location-dot text-gold-500 mr-2"></i> Jakarta Selatan</span>
                                <span class="text-xs text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded">30 Menit Sampai</span>
                            </div>
                            <p class="text-xs text-slate-500 mt-1">
                                SCBD, Senopati, Kemang, Kuningan, Kebayoran Baru, Blok M, Pondok Indah, Tebet, Cilandak, Pasar Minggu, Gandaria, Pancoran.
                            </p>
                        </div>

                        <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                            <div class="flex items-center justify-between font-bold text-navy-900 text-sm">
                                <span class="flex items-center"><i class="fa-solid fa-location-dot text-gold-500 mr-2"></i> Jakarta Pusat</span>
                                <span class="text-xs text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded">30 Menit Sampai</span>
                            </div>
                            <p class="text-xs text-slate-500 mt-1">
                                MH Thamrin, Sudirman, Menteng, Tanah Abang, Senayan, Gambir, Cikini, Kemayoran, Salemba, Bendungan Hilir.
                            </p>
                        </div>

                        <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                            <div class="flex items-center justify-between font-bold text-navy-900 text-sm">
                                <span class="flex items-center"><i class="fa-solid fa-location-dot text-gold-500 mr-2"></i> Jakarta Barat</span>
                                <span class="text-xs text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded">35 Menit Sampai</span>
                            </div>
                            <p class="text-xs text-slate-500 mt-1">
                                Tomang, Slipi, Grogol, Tanjung Duren, Kebon Jeruk, Puri Indah, Taman Anggrek, Palmerah, Meruya.
                            </p>
                        </div>

                        <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                            <div class="flex items-center justify-between font-bold text-navy-900 text-sm">
                                <span class="flex items-center"><i class="fa-solid fa-location-dot text-gold-500 mr-2"></i> Jakarta Utara & Jakarta Timur</span>
                                <span class="text-xs text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded">35 - 45 Menit Sampai</span>
                            </div>
                            <p class="text-xs text-slate-500 mt-1">
                                Pluit, Pantai Indah Kapuk (PIK), Kelapa Gading, Sunter, Ancol, Rawamangun, Cawang, Matraman, Jatinegara.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-6">
                    <div class="rounded-3xl bg-gradient-to-tr from-navy-900 via-navy-800 to-slate-900 p-8 text-white relative shadow-2xl overflow-hidden border border-slate-700">
                        <div class="relative z-10 space-y-6">
                            <div class="inline-flex items-center space-x-2 text-xs text-gold-400 font-semibold uppercase tracking-wider">
                                <i class="fa-solid fa-hotel"></i>
                                <span>Hotel & Apartemen Specialist</span>
                            </div>
                            <h3 class="text-2xl sm:text-3xl font-bold font-serif leading-snug">
                                Menginap di Hotel atau Apartemen Jakarta?
                            </h3>
                            <p class="text-sm text-slate-300 leading-relaxed">
                                Anda tidak perlu repot keluar hotel di tengah kemacetan Jakarta. Cukup kirimkan nama hotel, nomor kamar, dan jenis layanan yang diinginkan. Terapis kami akan segera tiba dengan perlengkapan lengkap dan siap melayani Anda.
                            </p>

                            <div class="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
                                <div class="flex items-center text-xs text-slate-300">
                                    <i class="fa-solid fa-circle-check text-emerald-400 mr-2"></i>
                                    <span>Terapis berpenampilan bersih, sopan, & rapi</span>
                                </div>
                                <div class="flex items-center text-xs text-slate-300">
                                    <i class="fa-solid fa-circle-check text-emerald-400 mr-2"></i>
                                    <span>Membawa minyak aromaterapi, kain alas, & perlengkapan higienis</span>
                                </div>
                                <div class="flex items-center text-xs text-slate-300">
                                    <i class="fa-solid fa-circle-check text-emerald-400 mr-2"></i>
                                    <span>Pembayaran fleksibel (Transfer Bank / Cash langsung)</span>
                                </div>
                            </div>

                            <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya sedang menginap di hotel/apartemen di Jakarta dan ingin panggil terapis pijat.')); ?>"
                               target="_blank"
                               rel="noopener noreferrer"
                               class="inline-flex items-center justify-center w-full py-3.5 px-6 rounded-xl bg-gold-500 hover:bg-gold-600 text-navy-950 font-bold text-sm shadow-lg transition-transform active:scale-95">
                                <i class="fa-brands fa-whatsapp text-lg mr-2"></i> Tanya Ketersediaan Terapis Terdekat
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION TARIF / TABEL -->
    <section id="tarif" class="py-16 md:py-24 bg-slate-50 border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-16 space-y-3">
                <span class="text-xs font-bold uppercase tracking-widest text-gold-600 bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                    Paket Hemat & Transparan
                </span>
                <h2 class="text-3xl sm:text-4xl font-bold font-serif text-navy-900">
                    Daftar Harga Pijat Panggilan Jakarta
                </h2>
                <p class="text-slate-600 text-sm sm:text-base leading-relaxed">
                    Tarif bersahabat, tanpa pungutan biaya misterius. Sudah termasuk minyak relaksasi pilihan.
                </p>
            </div>

            <div class="max-w-4xl mx-auto bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead class="bg-navy-950 text-white text-xs uppercase tracking-wider">
                            <tr>
                                <th scope="col" class="py-4 px-6 font-semibold">Jenis Layanan</th>
                                <th scope="col" class="py-4 px-4 font-semibold text-center">Durasi</th>
                                <th scope="col" class="py-4 px-6 font-semibold text-right">Tarif</th>
                                <th scope="col" class="py-4 px-6 font-semibold text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 text-slate-700">
                            <tr class="hover:bg-slate-50/80 transition-colors">
                                <td class="py-4 px-6 font-medium text-navy-900">
                                    <div class="font-bold">Traditional Body Massage</div>
                                    <div class="text-xs text-slate-400">Pijat seluruh tubuh meredakan pegal linu</div>
                                </td>
                                <td class="py-4 px-4 text-center font-medium">90 Menit</td>
                                <td class="py-4 px-6 text-right font-bold text-navy-900">Rp 200.000</td>
                                <td class="py-4 px-6 text-center">
                                    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin order Traditional Massage 90 Menit.')); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                                        <i class="fa-brands fa-whatsapp mr-1.5"></i> Pesan
                                    </a>
                                </td>
                            </tr>
                            <tr class="hover:bg-slate-50/80 transition-colors bg-slate-50/40">
                                <td class="py-4 px-6 font-medium text-navy-900">
                                    <div class="font-bold">Traditional Body Massage (Long Session)</div>
                                    <div class="text-xs text-slate-400">Relaksasi tuntas dari kepala hingga ujung kaki</div>
                                </td>
                                <td class="py-4 px-4 text-center font-medium">120 Menit</td>
                                <td class="py-4 px-6 text-right font-bold text-navy-900">Rp 250.000</td>
                                <td class="py-4 px-6 text-center">
                                    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin order Traditional Massage 120 Menit.')); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                                        <i class="fa-brands fa-whatsapp mr-1.5"></i> Pesan
                                    </a>
                                </td>
                            </tr>
                            <tr class="hover:bg-slate-50/80 transition-colors">
                                <td class="py-4 px-6 font-medium text-navy-900">
                                    <div class="font-bold">Pijat Tradisional + Kerokan</div>
                                    <div class="text-xs text-slate-400">Pijat seluruh tubuh + kerokan masuk angin</div>
                                </td>
                                <td class="py-4 px-4 text-center font-medium">90 Menit</td>
                                <td class="py-4 px-6 text-right font-bold text-navy-900">Rp 225.000</td>
                                <td class="py-4 px-6 text-center">
                                    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin order Pijat + Kerokan 90 Menit.')); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                                        <i class="fa-brands fa-whatsapp mr-1.5"></i> Pesan
                                    </a>
                                </td>
                            </tr>
                            <tr class="hover:bg-slate-50/80 transition-colors bg-slate-50/40">
                                <td class="py-4 px-6 font-medium text-navy-900">
                                    <div class="font-bold">Lulur Herbal & Scrub Spa</div>
                                    <div class="text-xs text-slate-400">Pijat relaksasi 60 mnt + Lulur pembersih kulit 60 mnt</div>
                                </td>
                                <td class="py-4 px-4 text-center font-medium">120 Menit</td>
                                <td class="py-4 px-6 text-right font-bold text-navy-900">Rp 275.000</td>
                                <td class="py-4 px-6 text-center">
                                    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin order Lulur Herbal & Scrub Spa 120 Menit.')); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                                        <i class="fa-brands fa-whatsapp mr-1.5"></i> Pesan
                                    </a>
                                </td>
                            </tr>
                            <tr class="hover:bg-slate-50/80 transition-colors">
                                <td class="py-4 px-6 font-medium text-navy-900">
                                    <div class="font-bold">Deep Tissue / Pijat Otot Intensif</div>
                                    <div class="text-xs text-slate-400">Tekanan kuat untuk simpul otot kaku & atlet</div>
                                </td>
                                <td class="py-4 px-4 text-center font-medium">90 Menit</td>
                                <td class="py-4 px-6 text-right font-bold text-navy-900">Rp 250.000</td>
                                <td class="py-4 px-6 text-center">
                                    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin order Deep Tissue Massage 90 Menit.')); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                                        <i class="fa-brands fa-whatsapp mr-1.5"></i> Pesan
                                    </a>
                                </td>
                            </tr>
                            <tr class="hover:bg-slate-50/80 transition-colors bg-slate-50/40">
                                <td class="py-4 px-6 font-medium text-navy-900">
                                    <div class="font-bold">Couple Massage (Pasangan)</div>
                                    <div class="text-xs text-slate-400">2 Terapis datang bersamaan untuk Anda & pasangan</div>
                                </td>
                                <td class="py-4 px-4 text-center font-medium">120 Menit</td>
                                <td class="py-4 px-6 text-right font-bold text-navy-900">Rp 450.000</td>
                                <td class="py-4 px-6 text-center">
                                    <a href="<?php echo esc_url(daydreams_get_wa_link('Halo Admin Daydreams, saya ingin order Couple Massage (2 Orang).')); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                                        <i class="fa-brands fa-whatsapp mr-1.5"></i> Pesan
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION TESTIMONI -->
    <section id="testimoni" class="py-16 md:py-24 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-16 space-y-3">
                <span class="text-xs font-bold uppercase tracking-widest text-gold-600 bg-gold-50 px-3 py-1 rounded-full border border-gold-200">
                    Ulasan Asli Tamu
                </span>
                <h2 class="text-3xl sm:text-4xl font-bold font-serif text-navy-900">
                    Apa Kata Pelanggan Daydreams Massage Jakarta?
                </h2>
                <p class="text-slate-600 text-sm sm:text-base leading-relaxed">
                    Kepuasan dan kenyamanan Anda adalah prioritas mutlak kami. Simak testimoni nyata tamu hotel dan residen Jakarta.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="p-6 rounded-3xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                    <div>
                        <div class="flex text-amber-400 text-sm mb-4">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p class="text-slate-700 text-sm italic leading-relaxed mb-6">
                            "Lagi trip bisnis dan nginap di hotel area SCBD. Badan capek banget abis meeting seharian. Iseng kontak Daydreams jam 10 malam, terapisnya datang tepat waktu sekitar 35 menit. Pijatannya mantap, sopan, dan wangi minyaknya bikin langsung pules."
                        </p>
                    </div>
                    <div class="flex items-center space-x-3 pt-4 border-t border-slate-200/80">
                        <div class="w-10 h-10 rounded-full bg-navy-900 text-gold-400 font-bold flex items-center justify-center text-sm">RH</div>
                        <div>
                            <div class="font-bold text-navy-900 text-sm">Rian H.</div>
                            <div class="text-xs text-slate-500">Tamu Hotel Bintang 5, SCBD Jaksel</div>
                        </div>
                    </div>
                </div>

                <div class="p-6 rounded-3xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                    <div>
                        <div class="flex text-amber-400 text-sm mb-4">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p class="text-slate-700 text-sm italic leading-relaxed mb-6">
                            "Saya dan suami pesan Couple Massage 120 menit ke apartemen di Thamrin. Pelayanannya sangat profesional dan menghormati privasi. 2 terapis datang barengan dengan seragam rapi dan ramah. Recommended banget buat yang gamau macet-macetan di jalan."
                        </p>
                    </div>
                    <div class="flex items-center space-x-3 pt-4 border-t border-slate-200/80">
                        <div class="w-10 h-10 rounded-full bg-gold-600 text-navy-950 font-bold flex items-center justify-center text-sm">AW</div>
                        <div>
                            <div class="font-bold text-navy-900 text-sm">Amanda & Suami</div>
                            <div class="text-xs text-slate-500">Residen Apartemen, Jakarta Pusat</div>
                        </div>
                    </div>
                </div>

                <div class="p-6 rounded-3xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
                    <div>
                        <div class="flex text-amber-400 text-sm mb-4">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p class="text-slate-700 text-sm italic leading-relaxed mb-6">
                            "Badan meriang dan masuk angin pas balik kerja lembur. Langsung pesen Pijat + Kerokan. Terapisnya ramah dan paham betul anatomi saraf punggung. Badan langsung enteng dan besoknya fit lagi. Fast response adminnya juara."
                        </p>
                    </div>
                    <div class="flex items-center space-x-3 pt-4 border-t border-slate-200/80">
                        <div class="w-10 h-10 rounded-full bg-blue-900 text-white font-bold flex items-center justify-center text-sm">DS</div>
                        <div>
                            <div class="font-bold text-navy-900 text-sm">Deni Setiawan</div>
                            <div class="text-xs text-slate-500">Rumah Tinggal, Kebon Jeruk Jakbar</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION CARA ORDER & BOOKING FORM -->
    <section id="booking" class="py-16 md:py-24 bg-gradient-to-b from-slate-900 to-navy-950 text-white relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center max-w-3xl mx-auto mb-16 space-y-3">
                <span class="text-xs font-bold uppercase tracking-widest text-gold-400 bg-gold-950/60 px-3 py-1 rounded-full border border-gold-500/30">
                    Proses Praktis & Cepat
                </span>
                <h2 class="text-3xl sm:text-4xl font-bold font-serif text-white">
                    Cara Pesan Pijat Panggilan Dalam 3 Langkah Mudah
                </h2>
                <p class="text-slate-300 text-sm sm:text-base leading-relaxed">
                    Tanpa perlu mendaftar atau instal aplikasi yang ribet. Cukup pesan lewat formulir di bawah atau langsung chat WhatsApp Admin kami.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
                <div class="bg-slate-800/60 p-6 rounded-2xl border border-slate-700 text-center relative">
                    <div class="w-12 h-12 rounded-full bg-gold-500 text-navy-950 font-extrabold text-lg flex items-center justify-center mx-auto mb-4">1</div>
                    <h3 class="text-lg font-bold text-white mb-2 font-serif">Pilih Layanan & Durasi</h3>
                    <p class="text-xs text-slate-400 leading-relaxed">
                        Tentukan jenis pijat (Tradisional, Refleksi, Scrub, Kerokan) serta durasi waktu yang Anda inginkan (60, 90, 120 menit).
                    </p>
                </div>
                <div class="bg-slate-800/60 p-6 rounded-2xl border border-slate-700 text-center relative">
                    <div class="w-12 h-12 rounded-full bg-gold-500 text-navy-950 font-extrabold text-lg flex items-center justify-center mx-auto mb-4">2</div>
                    <h3 class="text-lg font-bold text-white mb-2 font-serif">Kirim Alamat / Hotel</h3>
                    <p class="text-xs text-slate-400 leading-relaxed">
                        Sebutkan nama hotel dan nomor kamar, nama apartemen, atau share live location rumah Anda via WhatsApp admin.
                    </p>
                </div>
                <div class="bg-slate-800/60 p-6 rounded-2xl border border-slate-700 text-center relative">
                    <div class="w-12 h-12 rounded-full bg-gold-500 text-navy-950 font-extrabold text-lg flex items-center justify-center mx-auto mb-4">3</div>
                    <h3 class="text-lg font-bold text-white mb-2 font-serif">Terapis Langsung Meluncur</h3>
                    <p class="text-xs text-slate-400 leading-relaxed">
                        Terapis terdekat dari lokasi Anda segera menuju kamar Anda (estimasi 30-45 menit). Nikmati pijatan relaksasi tuntas!
                    </p>
                </div>
            </div>

            <div class="max-w-3xl mx-auto bg-slate-800/90 rounded-3xl p-6 sm:p-10 border border-slate-700 shadow-2xl backdrop-blur-md">
                <div class="text-center mb-8">
                    <h3 class="text-2xl font-bold font-serif text-white mb-2">Formulir Pemesanan Cepat via WhatsApp</h3>
                    <p class="text-xs sm:text-sm text-slate-300">
                        Isi form ringkas ini. Sistem akan otomatis menyusun format pesan WhatsApp siap kirim ke Admin Daydreams.
                    </p>
                </div>

                <form id="quick-booking-form" class="space-y-4 text-left">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="bf-nama" class="block text-xs font-semibold text-slate-300 mb-1.5">Nama Pemesan</label>
                            <input type="text" id="bf-nama" placeholder="Contoh: Bpk. Hendra" required
                                   class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500">
                        </div>
                        <div>
                            <label for="bf-layanan" class="block text-xs font-semibold text-slate-300 mb-1.5">Pilihan Layanan</label>
                            <select id="bf-layanan" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500">
                                <option value="Traditional Body Massage">Traditional Body Massage</option>
                                <option value="Reflexology & Totok Wajah">Reflexology & Totok Wajah</option>
                                <option value="Pijat Full Body + Kerokan">Pijat Full Body + Kerokan</option>
                                <option value="Lulur Herbal & Scrub Spa">Lulur Herbal & Scrub Spa</option>
                                <option value="Deep Tissue / Pijat Otot Bertenaga">Deep Tissue / Pijat Otot Bertenaga</option>
                                <option value="Couple Massage (Pasangan)">Couple Massage (Pasangan)</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="bf-durasi" class="block text-xs font-semibold text-slate-300 mb-1.5">Durasi Waktu</label>
                            <select id="bf-durasi" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500">
                                <option value="90 Menit">90 Menit (Paling Diminati)</option>
                                <option value="120 Menit">120 Menit (Puas & Maksimal)</option>
                                <option value="60 Menit">60 Menit (Refleksi / Quick)</option>
                            </select>
                        </div>
                        <div>
                            <label for="bf-gender" class="block text-xs font-semibold text-slate-300 mb-1.5">Preferensi Terapis</label>
                            <select id="bf-gender" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500">
                                <option value="Terapis Wanita">Terapis Wanita (Sopan & Ahli)</option>
                                <option value="Terapis Pria">Terapis Pria (Bertenaga & Ahli)</option>
                                <option value="Bebas / Siapa Saja Yang Ready">Bebas / Siapa Saja Yang Siap</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="bf-area" class="block text-xs font-semibold text-slate-300 mb-1.5">Wilayah Jakarta</label>
                            <select id="bf-area" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500">
                                <option value="Jakarta Selatan">Jakarta Selatan</option>
                                <option value="Jakarta Pusat">Jakarta Pusat</option>
                                <option value="Jakarta Barat">Jakarta Barat</option>
                                <option value="Jakarta Timur">Jakarta Timur</option>
                                <option value="Jakarta Utara">Jakarta Utara</option>
                            </select>
                        </div>
                        <div>
                            <label for="bf-waktu" class="block text-xs font-semibold text-slate-300 mb-1.5">Waktu Diinginkan</label>
                            <select id="bf-waktu" class="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500">
                                <option value="Sekarang / Secepatnya">Sekarang / Secepatnya (30-45 mnt)</option>
                                <option value="1 Jam Lagi">1 Jam Lagi</option>
                                <option value="Malam Ini (Pukul 21:00 - 24:00)">Malam Ini (Pukul 21:00 - 24:00)</option>
                                <option value="Dini Hari (24:00 - 05:00)">Dini Hari (24:00 - 05:00)</option>
                                <option value="Jadwal Besok Hari">Jadwal Besok Hari</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label for="bf-alamat" class="block text-xs font-semibold text-slate-300 mb-1.5">
                            Nama Hotel & No Kamar / Apartemen / Alamat Rumah
                        </label>
                        <textarea id="bf-alamat" rows="2" placeholder="Contoh: Hotel Mercure Gatot Subroto, Kamar 508" required
                                  class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold-500"></textarea>
                    </div>

                    <div class="pt-2">
                        <button type="submit"
                                class="w-full py-4 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-base shadow-lg transition-transform active:scale-98 flex items-center justify-center">
                            <i class="fa-brands fa-whatsapp text-2xl mr-2"></i>
                            <span>Kirim Booking Langsung ke WhatsApp Admin</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();
`
  },
  {
    name: 'index.php',
    path: 'index.php',
    language: 'php',
    description: 'Fallback loop standard WordPress theme jika halaman bukan static front page.',
    content: `<?php
/**
 * Main Template File (Fallback for Daydreams Massage Jakarta)
 *
 * @package Daydreams_Massage_Jakarta
 */

get_header();
?>

<main id="primary" class="site-main">
    <?php
    if (have_posts()) :
        if (is_front_page()) :
            get_template_part('front-page');
        else :
            ?>
            <div class="max-w-4xl mx-auto px-4 py-16">
                <?php
                while (have_posts()) :
                    the_post();
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('bg-white p-8 rounded-3xl shadow-sm border border-slate-200 mb-8'); ?>>
                        <header class="entry-header mb-6">
                            <?php the_title('<h1 class="text-3xl font-bold font-serif text-navy-900 mb-4">', '</h1>'); ?>
                        </header>
                        <div class="entry-content text-slate-700 leading-relaxed space-y-4">
                            <?php the_content(); ?>
                        </div>
                    </article>
                    <?php
                endwhile;
                ?>
            </div>
            <?php
        endif;
    else :
        ?>
        <div class="max-w-xl mx-auto px-4 py-24 text-center">
            <h2 class="text-2xl font-bold text-navy-900 font-serif mb-3">Halaman Tidak Ditemukan</h2>
            <p class="text-slate-600 mb-6">Maaf, konten yang Anda cari tidak tersedia. Silakan kembali ke beranda.</p>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="inline-flex items-center px-6 py-3 rounded-full bg-navy-900 text-white font-semibold text-sm">
                Kembali ke Beranda
            </a>
        </div>
        <?php
    endif;
    ?>
</main>

<?php
get_footer();`
  },
  {
    name: 'README.md',
    path: 'README.md',
    language: 'markdown',
    description: 'Panduan lengkap cara mengemas ZIP, upload ke WP Admin, setup Front Page & Customizer.',
    content: `# Daydreams Massage Jakarta - Custom WordPress Theme (SPA Landing Page)

Tema WordPress Single Page Application (SPA) modern, ultra-ringan, SEO-friendly, dan dioptimalkan secara khusus untuk konversi tinggi pemesanan jasa **Pijat Panggilan Jakarta 24 Jam** untuk brand:
**Daydreams Massage Jakarta** (https://daydreamsmassagejakarta.com/).

---

## 🌟 Fitur Utama Tema

1. **Desain Mobile-First & Ultra-Responsif**:
   - Lebih dari 90% pencari jasa pijat panggilan menggunakan smartphone.
   - Dilengkapi **Floating WhatsApp Button** dan **Mobile Bottom Booking Bar**.

2. **Single Page Application (SPA) Experience**:
   - Navigasi halus (*smooth scrolling*) ke setiap seksi: Beranda, Layanan, Keunggulan, Area Layanan, Tarif/Harga, Testimoni, dan Booking.

3. **Formulir Pemesanan Cepat Terintegrasi WhatsApp**:
   - Pemesan memilih layanan, durasi, gender terapis, wilayah Jakarta, waktu, & alamat/hotel.
   - Otomatis membuka aplikasi WhatsApp dengan pesan rapi.

4. **SEO & Schema.org Structured Data**:
   - Dilengkapi JSON-LD \`HealthAndBeautyBusiness\` Jakarta & OpenGraph meta tags.

5. **Tanpa Build Tool yang Rumit**:
   - Menggunakan Tailwind CSS CDN terkonfigurasi otomatis lewat \`functions.php\`.

---

## 📁 Struktur File Tema

\`\`\`text
daydreams-massage-theme/
├── style.css           # Metadata tema WordPress & styling custom
├── index.php           # Fallback template utama
├── functions.php       # Enqueue Tailwind, FontAwesome, fonts, & Customizer
├── header.php          # Tag <head>, SEO meta tags, Schema.org, & Fixed Navbar
├── footer.php          # Footer info, floating WA button, & JavaScript
├── front-page.php      # Template utama SPA (Hero, Layanan, Area, Testimoni, Form)
├── README.md           # Dokumentasi & panduan instalasi
└── LICENSE             # Lisensi GNU General Public License v2
\`\`\`

---

## 🚀 Panduan Instalasi di WordPress

### Langkah 1: Mengemas Folder Menjadi File \`.zip\`
Folder \`daydreams-massage-theme\` dikompres menjadi file zip bernama \`daydreams-massage-theme.zip\`.
*Atau klik tombol "Download Theme .ZIP" pada web preview ini.*

### Langkah 2: Upload ke Dashboard WordPress
1. Buka WordPress Admin > **Appearance (Tampilan)** > **Themes (Tema)**.
2. Klik **Add New (Tambah Baru)** > **Upload Theme**.
3. Pilih file \`daydreams-massage-theme.zip\` lalu klik **Install Now**.
4. Klik **Activate (Aktifkan)**.

### Langkah 3: Mengatur Halaman Utama (Front Page)
1. Buka **Pages** > **Add New** > Beri judul "Beranda".
2. Pada atribut template di sidebar kanan, pilih template **"Front Page SPA Landing Page"**.
3. Klik **Publish**.
4. Buka **Settings** > **Reading** > Pada "Your homepage displays" pilih **A static page**, dan pilih "Beranda".
5. Simpan pengaturan.

### Langkah 4: Mengatur Nomor WhatsApp Admin
1. Buka **Appearance** > **Customize** > **Pengaturan Kontak & WhatsApp**.
2. Masukkan nomor WhatsApp tujuan (contoh: \`6281234567890\`).
3. Klik **Publish**.

---

## 📜 Lisensi
GNU General Public License v2 or later (GPL-2.0).`
  },
  {
    name: 'LICENSE',
    path: 'LICENSE',
    language: 'text',
    description: 'Lisensi resmi GNU General Public License v2.0 untuk tema WordPress.',
    content: `GNU GENERAL PUBLIC LICENSE
Version 2, June 1991

Copyright (C) 2026 Daydreams Massage Jakarta
Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble & Terms:
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.`
  }
];
